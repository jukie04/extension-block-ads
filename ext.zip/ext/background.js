// ============================================================
// NextDNS Shield - Background Service Worker
// Enhanced with EasyList + NextDNS denylist sync
// ============================================================

const NEXTDNS_API = 'https://api.nextdns.io';
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Filter list URLs (like AdBlock)
const FILTER_LISTS = {
  easylist: 'https://easylist.to/easylist/easylist.txt',
  easyprivacy: 'https://easylist.to/easylist/easyprivacy.txt',
  antiadblock: 'https://easylist-downloads.adblockplus.org/antiadblockfilters.txt',
};

// Dynamic rule ID ranges
const DYNAMIC_RULE_START = 10000;
const DYNAMIC_RULE_NEXTDNS_START = 20000;
const MAX_DYNAMIC_RULES = 4999;

// Default settings
const DEFAULT_SETTINGS = {
  enabled: true,
  apiKey: 'ade4a75f621eaf6ec85239208446fa5438299481',
  profileId: 'e26da4',
  cosmeticFiltering: true,
  whitelist: [],
  totalBlocked: 0,
  todayBlocked: 0,
  todayDate: new Date().toDateString(),
  filterListsEnabled: true,
  lastFilterUpdate: 0,
  nextdnsSyncEnabled: true,
};

// In-memory state
let tabBlockCounts = {};
let nextdnsCache = { data: null, timestamp: 0 };

// ============================================================
// Initialization
// ============================================================
chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get(null);
  if (!stored.apiKey) {
    await chrome.storage.local.set(DEFAULT_SETTINGS);
  }
  console.log('[NextDNS Shield] Extension installed');
  setTimeout(() => updateFilterLists(), 3000);
  setTimeout(() => syncNextDNSDenylist(), 5000);
});

// ============================================================
// Auto-close/revert tabs navigating to gambling/ad domains (popunder protection)
// ============================================================
const GAMBLING_DOMAINS = [
  '789bet', 'i9bet', 'bet88', 'fb88', 'w88', '188bet', 'fun88', 'vn88',
  'sbobet', 'bong88', 'ae888', 'hi88', 'new88', 'shbet', 'debet',
  'kubet', 'jun88', 'may88', 'mb66', 'go88', 'sin88', 'sv388',
  'sunwin', 'iwin', 'b52', 'yo88', 'ta88', 'luck8', 'typhu88',
  '789club', 'cm88', 'c168', 'qq88', 'oxbet', 'onbet',
  'hbet', 'lu88', 'gbong', 'xibet', 'usbet', 'k88', 'man88',
  'xnhau.blog', 'bit.ly', 'zorvec', 'adxcontent',
  'trafficstars', 'exosrv', 'realsrv', 'hilltopads', 'clickadu',
  'onclickmax', 'monetag', 'galaksion', 'pushground',
  'anytimebananarecoil'
];

function isGamblingUrl(url) {
  if (!url) return false;
  const lower = url.toLowerCase();
  return GAMBLING_DOMAINS.some(d => lower.includes(d));
}

// Track previous URLs for each tab (to revert tab-under attacks)
const tabPrevUrls = {};

// LOG ALL tab creations for debugging
chrome.tabs.onCreated.addListener((tab) => {
  const url = tab.pendingUrl || tab.url || '';
  console.log('[TAB-CREATED]', { id: tab.id, url: url, openerTabId: tab.openerTabId, pendingUrl: tab.pendingUrl });
  
  if (url && isGamblingUrl(url)) {
    console.log('[TAB-BLOCKED] Closing gambling tab:', url);
    chrome.tabs.remove(tab.id).catch(() => {});
    return;
  }
  
  // Block any external tab opened by a known site (popunder pattern)
  if (tab.openerTabId && url) {
    chrome.tabs.get(tab.openerTabId, (opener) => {
      if (chrome.runtime.lastError) return;
      const openerUrl = opener.url || '';
      // If opener is xnhau/adult site and new tab is external
      if (openerUrl.includes('xnhau') || openerUrl.includes('vlxx') || openerUrl.includes('hentaivietsub')) {
        try {
          const newHost = new URL(url).hostname;
          const openerHost = new URL(openerUrl).hostname;
          if (newHost !== openerHost && !url.startsWith('chrome') && !url.startsWith('edge') && !url.startsWith('about')) {
            console.log('[POPUNDER-BLOCKED] External tab from', openerHost, '→', url);
            chrome.tabs.remove(tab.id).catch(() => {});
          }
        } catch(e) {}
      }
    });
  }
});

// Monitor tab URL changes - revert if navigated to gambling
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url) {
    console.log('[TAB-UPDATED]', { id: tabId, newUrl: changeInfo.url, prevUrl: tabPrevUrls[tabId] });
    
    if (isGamblingUrl(changeInfo.url)) {
      console.log('[TAB-HIJACK] Reverting gambling navigation:', changeInfo.url);
      const prevUrl = tabPrevUrls[tabId];
      if (prevUrl) {
        chrome.tabs.update(tabId, { url: prevUrl }).catch(() => {});
      } else {
        chrome.tabs.goBack(tabId).catch(() => {
          chrome.tabs.remove(tabId).catch(() => {});
        });
      }
    } else {
      if (changeInfo.url.startsWith('http')) {
        tabPrevUrls[tabId] = changeInfo.url;
      }
    }
  }
});

// Clean up tab history when tab closes
chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabPrevUrls[tabId];
});

// Intercept navigation to gambling before it starts
if (chrome.webNavigation) {
  chrome.webNavigation.onBeforeNavigate.addListener((details) => {
    if (details.frameId === 0 && isGamblingUrl(details.url)) {
      console.log('[NAV-BLOCKED] Intercepting:', details.url);
      const prevUrl = tabPrevUrls[details.tabId];
      if (prevUrl) {
        chrome.tabs.update(details.tabId, { url: prevUrl }).catch(() => {});
      } else {
        chrome.tabs.goBack(details.tabId).catch(() => {
          chrome.tabs.remove(details.tabId).catch(() => {});
        });
      }
    }
  });
}


// ============================================================
// Track blocked requests
// ============================================================
if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
  chrome.declarativeNetRequest.onRuleMatchedDebug.addListener(async (info) => {
    const tabId = info.request.tabId;
    if (tabId > 0) {
      tabBlockCounts[tabId] = (tabBlockCounts[tabId] || 0) + 1;
      updateBadge(tabId);
    }
    await incrementBlockCount();
  });
}

async function pollMatchedRules() {
  try {
    const settings = await chrome.storage.local.get(['enabled']);
    if (!settings.enabled) return;
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs.length > 0) {
      const tabId = tabs[0].id;
      const matchedRules = await chrome.declarativeNetRequest.getMatchedRules({ tabId });
      if (matchedRules && matchedRules.rulesMatchedInfo) {
        const count = matchedRules.rulesMatchedInfo.length;
        if (count > (tabBlockCounts[tabId] || 0)) {
          const diff = count - (tabBlockCounts[tabId] || 0);
          tabBlockCounts[tabId] = count;
          updateBadge(tabId);
          const stored = await chrome.storage.local.get(['totalBlocked', 'todayBlocked', 'todayDate']);
          const today = new Date().toDateString();
          let todayBlocked = stored.todayBlocked || 0;
          if (stored.todayDate !== today) todayBlocked = 0;
          await chrome.storage.local.set({
            totalBlocked: (stored.totalBlocked || 0) + diff,
            todayBlocked: todayBlocked + diff,
            todayDate: today
          });
        }
      }
    }
  } catch (e) { /* silent */ }
}
setInterval(pollMatchedRules, 2000);

// ============================================================
// Badge
// ============================================================
function updateBadge(tabId) {
  const count = tabBlockCounts[tabId] || 0;
  const text = count > 999 ? `${Math.floor(count/1000)}k` : count.toString();
  chrome.action.setBadgeText({ text: count > 0 ? text : '', tabId });
  chrome.action.setBadgeBackgroundColor({ color: '#6C5CE7', tabId });
  chrome.action.setBadgeTextColor({ color: '#FFFFFF', tabId });
}

// ============================================================
// Block count
// ============================================================
async function incrementBlockCount() {
  try {
    const stored = await chrome.storage.local.get(['totalBlocked', 'todayBlocked', 'todayDate']);
    const today = new Date().toDateString();
    let todayBlocked = stored.todayBlocked || 0;
    if (stored.todayDate !== today) todayBlocked = 0;
    await chrome.storage.local.set({
      totalBlocked: (stored.totalBlocked || 0) + 1,
      todayBlocked: todayBlocked + 1,
      todayDate: today
    });
  } catch (e) {
    console.error('[NextDNS Shield] Error:', e);
  }
}

// ============================================================
// Tab management
// ============================================================
chrome.tabs.onRemoved.addListener((tabId) => { delete tabBlockCounts[tabId]; });
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'loading') {
    tabBlockCounts[tabId] = 0;
    updateBadge(tabId);
  }
});

// ============================================================
// NextDNS API
// ============================================================
async function fetchNextDNS(endpoint) {
  const settings = await chrome.storage.local.get(['apiKey', 'profileId']);
  if (!settings.apiKey || !settings.profileId) return null;
  try {
    const response = await fetch(`${NEXTDNS_API}/profiles/${settings.profileId}${endpoint}`, {
      headers: { 'X-Api-Key': settings.apiKey }
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    return await response.json();
  } catch (e) {
    console.error('[NextDNS Shield] API error:', e);
    return null;
  }
}

async function getNextDNSAnalytics() {
  const now = Date.now();
  if (nextdnsCache.data && (now - nextdnsCache.timestamp) < CACHE_DURATION) {
    return nextdnsCache.data;
  }
  const [domains, blockedDomains, profile] = await Promise.all([
    fetchNextDNS('/analytics/domains'),
    fetchNextDNS('/analytics/domains?status=blocked'),
    fetchNextDNS('')
  ]);
  const analytics = {
    totalQueries: 0, blockedQueries: 0, blockRate: 0,
    topBlocked: [], topDomains: [], profile: profile?.data || null
  };
  if (domains?.data) {
    analytics.totalQueries = domains.data.reduce((sum, d) => sum + (d.queries || 0), 0);
    analytics.topDomains = domains.data.slice(0, 5);
  }
  if (blockedDomains?.data) {
    analytics.blockedQueries = blockedDomains.data.reduce((sum, d) => sum + (d.queries || 0), 0);
    analytics.topBlocked = blockedDomains.data.slice(0, 5);
  }
  if (analytics.totalQueries > 0) {
    analytics.blockRate = Math.round((analytics.blockedQueries / analytics.totalQueries) * 100);
  }
  nextdnsCache.data = analytics;
  nextdnsCache.timestamp = now;
  return analytics;
}

// ============================================================
// EasyList Filter List Engine
// ============================================================
function parseFilterList(text) {
  const domains = new Set();
  const lines = text.split('\n');
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('!') || line.startsWith('[')) continue;
    if (line.includes('##') || line.includes('#@#') || line.startsWith('@@')) continue;
    if (line.includes('$popup') || line.includes('$document')) continue;
    const domainMatch = line.match(/^\|\|([a-z0-9][\w\-\.]*\.[a-z]{2,})\^?\s*(\$.*)?$/i);
    if (domainMatch) {
      const domain = domainMatch[1].toLowerCase();
      if (domain.length > 3 && domain.includes('.') && !domain.startsWith('.')) {
        domains.add(domain);
      }
    }
  }
  return Array.from(domains);
}

function domainsToRules(domains, startId) {
  return domains.map((domain, index) => ({
    id: startId + index,
    priority: 1,
    action: { type: 'block' },
    condition: {
      urlFilter: `||${domain}`,
      resourceTypes: ['script', 'image', 'sub_frame', 'xmlhttprequest', 'media', 'font', 'stylesheet', 'other']
    }
  }));
}

async function updateFilterLists() {
  try {
    const settings = await chrome.storage.local.get(['filterListsEnabled']);
    if (settings.filterListsEnabled === false) return;
    console.log('[NextDNS Shield] Updating filter lists...');
    const allDomains = new Set();
    for (const [name, url] of Object.entries(FILTER_LISTS)) {
      try {
        const response = await fetch(url);
        if (!response.ok) continue;
        const text = await response.text();
        const domains = parseFilterList(text);
        domains.forEach(d => allDomains.add(d));
        console.log(`[NextDNS Shield] ${name}: parsed ${domains.length} domains`);
      } catch (e) {
        console.warn(`[NextDNS Shield] Failed to fetch ${name}:`, e);
      }
    }
    if (allDomains.size === 0) return;
    const maxFilterRules = MAX_DYNAMIC_RULES - 1000;
    const domainArray = Array.from(allDomains).slice(0, maxFilterRules);
    const newRules = domainsToRules(domainArray, DYNAMIC_RULE_START);
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const filterRuleIds = existingRules
      .filter(r => r.id >= DYNAMIC_RULE_START && r.id < DYNAMIC_RULE_NEXTDNS_START)
      .map(r => r.id);
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: filterRuleIds,
      addRules: newRules
    });
    await chrome.storage.local.set({ lastFilterUpdate: Date.now(), filterRuleCount: newRules.length });
    console.log(`[NextDNS Shield] Applied ${newRules.length} dynamic filter rules`);
  } catch (e) {
    console.error('[NextDNS Shield] Error updating filter lists:', e);
  }
}

// ============================================================
// NextDNS Denylist Sync
// ============================================================
async function syncNextDNSDenylist() {
  try {
    const settings = await chrome.storage.local.get(['apiKey', 'profileId', 'nextdnsSyncEnabled']);
    if (!settings.apiKey || !settings.profileId || settings.nextdnsSyncEnabled === false) return;
    console.log('[NextDNS Shield] Syncing NextDNS denylist...');
    const profile = await fetchNextDNS('');
    if (!profile?.data?.denylist) return;
    const denylist = profile.data.denylist;
    if (denylist.length === 0) return;
    const domains = denylist.map(entry => entry.id || entry).filter(Boolean);
    const newRules = domainsToRules(domains, DYNAMIC_RULE_NEXTDNS_START);
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const nextdnsRuleIds = existingRules.filter(r => r.id >= DYNAMIC_RULE_NEXTDNS_START).map(r => r.id);
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: nextdnsRuleIds,
      addRules: newRules.slice(0, 1000)
    });
    console.log(`[NextDNS Shield] Synced ${Math.min(newRules.length, 1000)} NextDNS denylist rules`);
  } catch (e) {
    console.error('[NextDNS Shield] Error syncing NextDNS denylist:', e);
  }
}

// ============================================================
// Periodic updates
// ============================================================
const FILTER_UPDATE_INTERVAL = 24 * 60 * 60 * 1000;
async function checkForUpdates() {
  const settings = await chrome.storage.local.get(['lastFilterUpdate']);
  const elapsed = Date.now() - (settings.lastFilterUpdate || 0);
  if (elapsed > FILTER_UPDATE_INTERVAL) {
    await updateFilterLists();
    await syncNextDNSDenylist();
  }
}
setInterval(checkForUpdates, 60 * 60 * 1000);
setTimeout(checkForUpdates, 10000);

// ============================================================
// Toggle
// ============================================================
async function toggleExtension(enabled) {
  await chrome.storage.local.set({ enabled });
  if (enabled) {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ enableRulesetIds: ['adblock_rules'] });
  } else {
    await chrome.declarativeNetRequest.updateEnabledRulesets({ disableRulesetIds: ['adblock_rules'] });
  }
  const tabs = await chrome.tabs.query({});
  for (const tab of tabs) {
    if (!enabled) {
      chrome.action.setBadgeText({ text: '', tabId: tab.id });
    } else {
      updateBadge(tab.id);
    }
  }
}

// ============================================================
// Whitelist
// ============================================================
async function isWhitelisted(url) {
  try {
    const { whitelist } = await chrome.storage.local.get(['whitelist']);
    if (!whitelist || !url) return false;
    const hostname = new URL(url).hostname;
    return whitelist.some(domain => hostname === domain || hostname.endsWith('.' + domain));
  } catch { return false; }
}

// ============================================================
// Message handling
// ============================================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    switch (message.type) {
      case 'GET_STATS': {
        const settings = await chrome.storage.local.get([
          'enabled', 'totalBlocked', 'todayBlocked', 'todayDate', 'filterRuleCount', 'lastFilterUpdate'
        ]);
        const today = new Date().toDateString();
        let todayBlocked = settings.todayBlocked || 0;
        if (settings.todayDate !== today) todayBlocked = 0;
        const tabId = message.tabId;
        const pageBlocked = tabBlockCounts[tabId] || 0;
        let dynamicRuleCount = 0;
        try { const dr = await chrome.declarativeNetRequest.getDynamicRules(); dynamicRuleCount = dr.length; } catch(e) {}
        sendResponse({
          enabled: settings.enabled !== false,
          totalBlocked: settings.totalBlocked || 0,
          todayBlocked, pageBlocked,
          filterRuleCount: (settings.filterRuleCount || 0) + 200,
          dynamicRuleCount,
          lastFilterUpdate: settings.lastFilterUpdate || 0
        });
        break;
      }
      case 'GET_NEXTDNS': {
        const analytics = await getNextDNSAnalytics();
        sendResponse(analytics);
        break;
      }
      case 'TOGGLE': {
        await toggleExtension(message.enabled);
        sendResponse({ success: true });
        break;
      }
      case 'GET_SETTINGS': {
        const settings = await chrome.storage.local.get(null);
        sendResponse(settings);
        break;
      }
      case 'SAVE_SETTINGS': {
        await chrome.storage.local.set(message.settings);
        nextdnsCache.data = null;
        nextdnsCache.timestamp = 0;
        sendResponse({ success: true });
        break;
      }
      case 'CHECK_WHITELIST': {
        const whitelisted = await isWhitelisted(message.url);
        sendResponse({ whitelisted });
        break;
      }
      case 'UPDATE_FILTERS': {
        await updateFilterLists();
        await syncNextDNSDenylist();
        sendResponse({ success: true });
        break;
      }
      case 'GET_RULE_COUNT': {
        try {
          const dr = await chrome.declarativeNetRequest.getDynamicRules();
          sendResponse({ staticRules: 200, dynamicRules: dr.length, total: 200 + dr.length });
        } catch(e) {
          sendResponse({ staticRules: 200, dynamicRules: 0, total: 200 });
        }
        break;
      }
      default:
        sendResponse({ error: 'Unknown message type' });
    }
  })();
  return true;
});

console.log('[NextDNS Shield] Service worker started (Enhanced with EasyList + NextDNS sync)');
