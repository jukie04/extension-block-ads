// ============================================================
// NextDNS Shield - Popup Script
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
  const toggleInput = document.getElementById('toggleInput');
  const statusText = document.getElementById('statusText');
  const pageBlocked = document.getElementById('pageBlocked');
  const todayBlocked = document.getElementById('todayBlocked');
  const totalBlocked = document.getElementById('totalBlocked');
  const dnsQueries = document.getElementById('dnsQueries');
  const dnsBlocked = document.getElementById('dnsBlocked');
  const blockRateFill = document.getElementById('blockRateFill');
  const blockRateText = document.getElementById('blockRateText');
  const topBlockedList = document.getElementById('topBlockedList');
  const refreshBtn = document.getElementById('refreshBtn');
  const whitelistBtn = document.getElementById('whitelistBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const container = document.querySelector('.popup-container');

  // ========== Utility Functions ==========
  function formatNumber(num) {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  }

  function animateValue(element, start, end, duration = 600) {
    if (start === end) {
      element.textContent = formatNumber(end);
      return;
    }
    const startTime = performance.now();
    const diff = end - start;

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(start + diff * eased);
      element.textContent = formatNumber(current);

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        element.classList.add('count-up');
        setTimeout(() => element.classList.remove('count-up'), 300);
      }
    }
    requestAnimationFrame(update);
  }

  function showToast(message) {
    let toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
  }

  // ========== Load Stats ==========
  async function loadStats() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab) return;

      const stats = await chrome.runtime.sendMessage({ type: 'GET_STATS', tabId: tab.id });
      if (!stats) return;

      // Update toggle state
      toggleInput.checked = stats.enabled;
      updateToggleUI(stats.enabled);

      // Animate counters
      const currentPage = parseInt(pageBlocked.textContent.replace(/[KM]/g, '')) || 0;
      const currentToday = parseInt(todayBlocked.textContent.replace(/[KM]/g, '')) || 0;
      const currentTotal = parseInt(totalBlocked.textContent.replace(/[KM]/g, '')) || 0;

      animateValue(pageBlocked, currentPage, stats.pageBlocked);
      animateValue(todayBlocked, currentToday, stats.todayBlocked);
      animateValue(totalBlocked, currentTotal, stats.totalBlocked);

      // Check whitelist
      const whitelistResult = await chrome.runtime.sendMessage({ 
        type: 'CHECK_WHITELIST', 
        url: tab.url 
      });
      if (whitelistResult?.whitelisted) {
        whitelistBtn.classList.add('whitelisted');
        whitelistBtn.querySelector('span').textContent = 'Đã whitelist';
      }

    } catch (e) {
      console.error('Error loading stats:', e);
    }
  }

  // ========== Load NextDNS Analytics ==========
  async function loadNextDNS() {
    try {
      refreshBtn.classList.add('spinning');

      const analytics = await chrome.runtime.sendMessage({ type: 'GET_NEXTDNS' });

      refreshBtn.classList.remove('spinning');

      if (!analytics) {
        dnsQueries.textContent = 'Lỗi kết nối';
        dnsBlocked.textContent = '—';
        return;
      }

      // Update DNS stats
      dnsQueries.textContent = formatNumber(analytics.totalQueries);
      dnsBlocked.textContent = formatNumber(analytics.blockedQueries);

      // Animate progress bar
      setTimeout(() => {
        blockRateFill.style.width = analytics.blockRate + '%';
        blockRateText.textContent = analytics.blockRate + '%';
      }, 200);

      // Render top blocked domains
      renderTopBlocked(analytics.topBlocked);

    } catch (e) {
      console.error('Error loading NextDNS:', e);
      refreshBtn.classList.remove('spinning');
      dnsQueries.textContent = 'Lỗi';
    }
  }

  function renderTopBlocked(domains) {
    if (!domains || domains.length === 0) {
      topBlockedList.innerHTML = '<div class="domain-empty">Chưa có dữ liệu DNS</div>';
      return;
    }

    topBlockedList.innerHTML = domains.map((domain, index) => `
      <div class="domain-item fade-in" style="animation-delay: ${index * 80}ms">
        <span class="domain-name">${domain.name || domain.domain || 'unknown'}</span>
        <span class="domain-count">${formatNumber(domain.queries || 0)}</span>
      </div>
    `).join('');
  }

  // ========== Toggle Handler ==========
  function updateToggleUI(enabled) {
    if (enabled) {
      statusText.textContent = 'Đang bảo vệ';
      statusText.classList.remove('disabled');
      container.classList.remove('disabled');
    } else {
      statusText.textContent = 'Đã tắt';
      statusText.classList.add('disabled');
      container.classList.add('disabled');
    }
  }

  toggleInput.addEventListener('change', async () => {
    const enabled = toggleInput.checked;
    updateToggleUI(enabled);

    await chrome.runtime.sendMessage({ type: 'TOGGLE', enabled });
    showToast(enabled ? '🛡️ Đã bật bảo vệ' : '⚠️ Đã tắt bảo vệ');
  });

  // ========== Whitelist Handler ==========
  whitelistBtn.addEventListener('click', async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.url) return;

      const hostname = new URL(tab.url).hostname;
      const settings = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
      let whitelist = settings.whitelist || [];

      const index = whitelist.indexOf(hostname);
      if (index > -1) {
        whitelist.splice(index, 1);
        whitelistBtn.classList.remove('whitelisted');
        whitelistBtn.querySelector('span').textContent = 'Whitelist trang này';
        showToast(`🗑️ Đã xóa ${hostname} khỏi whitelist`);
      } else {
        whitelist.push(hostname);
        whitelistBtn.classList.add('whitelisted');
        whitelistBtn.querySelector('span').textContent = 'Đã whitelist';
        showToast(`✅ Đã thêm ${hostname} vào whitelist`);
      }

      await chrome.runtime.sendMessage({
        type: 'SAVE_SETTINGS',
        settings: { whitelist }
      });
    } catch (e) {
      console.error('Whitelist error:', e);
    }
  });

  // ========== Settings Handler ==========
  settingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });

  // ========== Refresh Handler ==========
  refreshBtn.addEventListener('click', () => {
    loadNextDNS();
  });

  // ========== Initialize ==========
  await loadStats();
  loadNextDNS();

  // Auto-refresh stats every 3 seconds
  setInterval(loadStats, 3000);
});
