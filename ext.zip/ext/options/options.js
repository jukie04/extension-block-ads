// ============================================================
// NextDNS Shield - Options Page Script
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
  const apiKeyInput = document.getElementById('apiKey');
  const profileIdInput = document.getElementById('profileId');
  const toggleApiKey = document.getElementById('toggleApiKey');
  const fetchProfilesBtn = document.getElementById('fetchProfiles');
  const cosmeticFilteringInput = document.getElementById('cosmeticFiltering');
  const newDomainInput = document.getElementById('newDomain');
  const addDomainBtn = document.getElementById('addDomain');
  const whitelistContainer = document.getElementById('whitelistContainer');
  const saveBtn = document.getElementById('saveBtn');
  const saveStatus = document.getElementById('saveStatus');
  const apiStatus = document.getElementById('apiStatus');

  let whitelist = [];

  // ========== Load Settings ==========
  async function loadSettings() {
    try {
      const settings = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
      
      apiKeyInput.value = settings.apiKey || '';
      profileIdInput.value = settings.profileId || '';
      cosmeticFilteringInput.checked = settings.cosmeticFiltering !== false;
      whitelist = settings.whitelist || [];

      renderWhitelist();

      // Check API status
      if (settings.apiKey && settings.profileId) {
        checkApiConnection(settings.apiKey, settings.profileId);
      }
    } catch (e) {
      console.error('Error loading settings:', e);
    }
  }

  // ========== API Connection Check ==========
  async function checkApiConnection(apiKey, profileId) {
    apiStatus.className = 'api-status';
    apiStatus.querySelector('.status-text').textContent = 'Đang kiểm tra...';

    try {
      const response = await fetch(`https://api.nextdns.io/profiles/${profileId}`, {
        headers: { 'X-Api-Key': apiKey }
      });

      if (response.ok) {
        const data = await response.json();
        apiStatus.className = 'api-status connected';
        apiStatus.querySelector('.status-text').textContent = 
          `✅ Đã kết nối — ${data.data.name || profileId}`;
      } else {
        apiStatus.className = 'api-status error';
        apiStatus.querySelector('.status-text').textContent = 
          `❌ Lỗi: ${response.status} — Kiểm tra lại API key/Profile ID`;
      }
    } catch (e) {
      apiStatus.className = 'api-status error';
      apiStatus.querySelector('.status-text').textContent = '❌ Không thể kết nối';
    }
  }

  // ========== Toggle API Key Visibility ==========
  toggleApiKey.addEventListener('click', () => {
    apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
  });

  // ========== Fetch Profiles ==========
  fetchProfilesBtn.addEventListener('click', async () => {
    const apiKey = apiKeyInput.value.trim();
    if (!apiKey) {
      showSaveStatus('Nhập API key trước', 'error');
      return;
    }

    fetchProfilesBtn.style.animation = 'spin 1s linear infinite';

    try {
      const response = await fetch('https://api.nextdns.io/profiles', {
        headers: { 'X-Api-Key': apiKey }
      });

      if (!response.ok) throw new Error('API error');

      const data = await response.json();
      if (data.data && data.data.length > 0) {
        profileIdInput.value = data.data[0].id;
        showSaveStatus(`Tìm thấy: ${data.data[0].name} (${data.data[0].id})`, 'success');
        checkApiConnection(apiKey, data.data[0].id);
      } else {
        showSaveStatus('Không tìm thấy profile', 'error');
      }
    } catch (e) {
      showSaveStatus('Lỗi kết nối API', 'error');
    }

    fetchProfilesBtn.style.animation = '';
  });

  // ========== Whitelist Management ==========
  function renderWhitelist() {
    if (whitelist.length === 0) {
      whitelistContainer.innerHTML = '<div class="whitelist-empty">Chưa có domain nào trong whitelist</div>';
      return;
    }

    whitelistContainer.innerHTML = whitelist.map((domain, index) => `
      <div class="whitelist-item">
        <span class="whitelist-domain">${domain}</span>
        <button class="btn-remove" data-index="${index}" title="Xóa">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
    `).join('');

    // Add remove handlers
    whitelistContainer.querySelectorAll('.btn-remove').forEach(btn => {
      btn.addEventListener('click', () => {
        const index = parseInt(btn.dataset.index);
        whitelist.splice(index, 1);
        renderWhitelist();
      });
    });
  }

  addDomainBtn.addEventListener('click', () => {
    const domain = newDomainInput.value.trim().toLowerCase();
    if (!domain) return;

    // Basic validation
    if (!/^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}$/.test(domain)) {
      showSaveStatus('Domain không hợp lệ', 'error');
      return;
    }

    if (whitelist.includes(domain)) {
      showSaveStatus('Domain đã tồn tại', 'error');
      return;
    }

    whitelist.push(domain);
    newDomainInput.value = '';
    renderWhitelist();
  });

  newDomainInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') addDomainBtn.click();
  });

  // ========== Save Settings ==========
  saveBtn.addEventListener('click', async () => {
    const settings = {
      apiKey: apiKeyInput.value.trim(),
      profileId: profileIdInput.value.trim(),
      cosmeticFiltering: cosmeticFilteringInput.checked,
      whitelist: whitelist
    };

    try {
      await chrome.runtime.sendMessage({ type: 'SAVE_SETTINGS', settings });
      showSaveStatus('✅ Đã lưu thành công!', 'success');

      // Re-check API connection
      if (settings.apiKey && settings.profileId) {
        checkApiConnection(settings.apiKey, settings.profileId);
      }
    } catch (e) {
      showSaveStatus('❌ Lỗi khi lưu', 'error');
    }
  });

  function showSaveStatus(message, type) {
    saveStatus.textContent = message;
    saveStatus.className = `save-status ${type}`;
    setTimeout(() => {
      saveStatus.textContent = '';
      saveStatus.className = 'save-status';
    }, 3000);
  }

  // ========== Initialize ==========
  await loadSettings();
});

// CSS spin animation for fetch button
const style = document.createElement('style');
style.textContent = '@keyframes spin { 100% { transform: rotate(360deg); } }';
document.head.appendChild(style);
