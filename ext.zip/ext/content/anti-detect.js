// ============================================================
// NextDNS Shield - Anti-Adblock Detection Bypass
// Injected at document_start in MAIN world
// ============================================================

(function() {
  'use strict';

  // ============================================================
  // -1. Block Popup/Redirect Ad Clicks (gambling sites)
  //     Prevents window.open and click-hijacking on video players
  // ============================================================

  // Block window.open to ad/gambling domains
  const AD_DOMAINS = [
    '9922.com', 'i9bet', 'i9.top', 'f8bet', 'phimbet', 'nhac88',
    'dk802', 'dk8', 'effectivecpmgate', 'popads', 'popcash',
    'trafficjunky', 'exoclick', 'juicyads', 'propellerads',
    '154.82.109.168', 'bdvn.com/tracker', 'bet', 'casino',
    'xoso66', 'vip66', 'jun88', 'sv388', 'sin88', 'go88',
    'sunwin', 'iwin', 'b52', 'rik', 'yo88', 'ta88', 'luck8',
    'kubet', 'nohu', 'typhu88', 'saowin', 'oxbet', 'w88',
    'fun88', '188bet', 'ae888', '789bet', 'hi88', 'new88',
    'shbet', 'thabet', 'v9bet', 'wbet', 'debet', 'bong88',
    'sbobet', 'onbet', 'may88', 'mb66', 'vn88', 'manclub',
    'adxcontent', 'trafficstars', 'tsyndicate', 'exosrv', 'realsrv',
    'padsdel', 'hilltopads', 'clickadu', 'a-ads.com',
    '789club', '789.club', 'johnterry',
    'zorvec', 'hbet.uk', 'lu88', 'gbong', 'xibet', 'usbet', 'k88.mobi', 'man88',
    'onclickmax', 'onclicka', 'monetag', 'richads', 'pushground',
    'adsterra', 'adskeeper', 'bidvertiser', 'highcpmrevenue', 'galaksion',
    'cm88', 'c168', 'qq88', 'new88.com',
    'xnhau.blog', 'bit.ly'
  ];

  const origWindowOpen = window.open;
  
  // ============================================================
  // Intercept addEventListener to block popunder click handlers
  // ============================================================
  const origAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, listener, options) {
    // Only intercept click/mousedown/mouseup/pointerdown on document/body
    if (type === 'click' || type === 'mousedown' || type === 'mouseup' || type === 'pointerdown') {
      if (this === document || this === document.documentElement || this === document.body || this === window) {
        // Check if the listener source code contains popunder patterns
        const src = listener.toString();
        if (src.includes('data-rt') || src.includes('popunder') || src.includes('popMagic') || 
            src.includes('exoclick') || src.includes('window.open') ||
            src.includes('tab-under') || src.includes('_blank') ||
            src.includes('clickCount') || src.includes('clicksRemain')) {
          // Block this listener entirely
          return;
        }
        // Wrap suspicious listeners to suppress window.open during execution
        const wrappedListener = function(e) {
          const saved = window.open;
          const clickedLink = e.target.closest && e.target.closest('a');
          const isInternalClick = clickedLink && clickedLink.hostname === window.location.hostname;
          
          if (isInternalClick) {
            // During internal link clicks, block ALL window.open
            window.open = function() { return null; };
          }
          try {
            listener.call(this, e);
          } finally {
            window.open = saved;
          }
        };
        return origAddEventListener.call(this, type, wrappedListener, options);
      }
    }
    return origAddEventListener.call(this, type, listener, options);
  };

  // Remove data-rt tracking attributes ASAP
  function removePopunderTracking() {
    document.querySelectorAll('[data-rt]').forEach(el => el.removeAttribute('data-rt'));
    document.querySelectorAll('[data-click-track]').forEach(el => el.removeAttribute('data-click-track'));
  }
  if (document.body) removePopunderTracking();
  document.addEventListener('DOMContentLoaded', removePopunderTracking);
  // Re-run periodically in case new elements are added
  setInterval(removePopunderTracking, 1000);

  // Track click context for popunder detection
  let _clickContext = null; // { target, clickedLink, isInternal, timestamp }
  
  // Capture ALL clicks to track context
  document.addEventListener('click', function(e) {
    const clickedLink = e.target.closest('a');
    const isInternal = clickedLink && (
      clickedLink.hostname === window.location.hostname || 
      clickedLink.hostname === '' ||
      clickedLink.getAttribute('href')?.startsWith('#') ||
      clickedLink.getAttribute('href')?.startsWith('/')
    );
    _clickContext = {
      target: e.target,
      clickedLink: clickedLink,
      isInternal: isInternal,
      href: clickedLink ? clickedLink.href : null,
      timestamp: Date.now()
    };
    // Clear context after event loop (500ms covers setTimeout popunders)
    setTimeout(() => { _clickContext = null; }, 500);
  }, true);

  // Smart window.open blocker  
  window.open = function(url) {
    // Always block ad domain URLs
    if (url && typeof url === 'string') {
      const lowerUrl = url.toLowerCase();
      if (AD_DOMAINS.some(d => lowerUrl.includes(d))) {
        return null;
      }
    }
    
    // Check click context
    if (_clickContext) {
      const { clickedLink, isInternal, href } = _clickContext;
      
      // Pattern 1: User clicked a same-site link
      if (isInternal) {
        // Only block if window.open URL is EXTERNAL (popunder)
        if (url && typeof url === 'string' && !url.includes(window.location.hostname)) {
          return null;
        }
        // Allow same-site window.open (might be legitimate redirect by tab-under script)
      }
      
      // Pattern 2: User didn't click any link → background popunder
      if (!clickedLink) {
        if (url && typeof url === 'string' && !url.includes(window.location.hostname)) {
          return null;
        }
      }
      
      // Pattern 3: User clicked an external link, but window.open URL is a DIFFERENT external site
      if (clickedLink && !isInternal && url !== href) {
        const urlLower = (url || '').toLowerCase();
        if (!urlLower.includes(window.location.hostname)) {
          return null;
        }
      }
    }
    
    // No click context = programmatic open
    if (!_clickContext && url && typeof url === 'string') {
      const lowerUrl = url.toLowerCase();
      if (!lowerUrl.includes(window.location.hostname)) {
        return null; // Block external programmatic opens
      }
    }
    
    return origWindowOpen.apply(window, arguments);
  };

  // ============================================================
  // Block programmatic anchor.click() popunders
  // ============================================================
  const origAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function() {
    const href = (this.href || '').toLowerCase();
    const target = this.target;
    // Block if it's a programmatic click on external link with target="_blank"
    if (target === '_blank' && href && !href.includes(window.location.hostname)) {
      if (isAdUrl(href)) return; // Known ad domain
      // Check if this anchor was created recently (likely by popunder script)
      if (!this.parentElement || !document.body.contains(this)) {
        return; // Anchor not in DOM = created by script for popunder
      }
    }
    return origAnchorClick.apply(this, arguments);
  };

  // ============================================================
  // Block location-based redirects to ad/gambling sites
  // ============================================================
  function isAdUrl(url) {
    if (!url || typeof url !== 'string') return false;
    const lower = url.toLowerCase();
    return AD_DOMAINS.some(d => lower.includes(d));
  }

  // Intercept location.assign() / location.replace()
  try {
    const origAssign = window.location.assign.bind(window.location);
    Object.defineProperty(window.location, 'assign', {
      value: function(url) { if (isAdUrl(url)) return; return origAssign(url); },
      configurable: true
    });
  } catch(e) {}
  try {
    const origReplace = window.location.replace.bind(window.location);
    Object.defineProperty(window.location, 'replace', {
      value: function(url) { if (isAdUrl(url)) return; return origReplace(url); },
      configurable: true
    });
  } catch(e) {}


  // Block navigation via meta refresh to ad sites
  const metaObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.tagName === 'META' && node.httpEquiv && node.httpEquiv.toLowerCase() === 'refresh') {
          const content = (node.content || '').toLowerCase();
          if (isAdUrl(content)) {
            node.remove();
          }
        }
      }
    }
  });
  if (document.head) {
    metaObserver.observe(document.head, { childList: true });
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (document.head) metaObserver.observe(document.head, { childList: true });
    // Remove existing meta refresh to ad sites
    document.querySelectorAll('meta[http-equiv="refresh"]').forEach(meta => {
      if (isAdUrl(meta.content || '')) meta.remove();
    });
  });


  // Intercept click events that try to navigate to ad URLs
  document.addEventListener('click', function(e) {
    var target = e.target;
    // Walk up the DOM tree to find anchor tags
    while (target && target !== document) {
      if (target.tagName === 'A' && target.href) {
        const href = target.href.toLowerCase();
        for (let i = 0; i < AD_DOMAINS.length; i++) {
          if (href.includes(AD_DOMAINS[i])) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            return false;
          }
        }
      }
      target = target.parentElement;
    }
  }, true); // Use capture phase to intercept before page handlers

  // Block programmatic form submissions to ad URLs
  const origFormSubmit = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function() {
    if (this.action) {
      const action = this.action.toLowerCase();
      for (let i = 0; i < AD_DOMAINS.length; i++) {
        if (action.includes(AD_DOMAINS[i])) return;
      }
    }
    return origFormSubmit.apply(this, arguments);
  };

  // ============================================================
  // -0.5. Block dynamically inserted ad scripts/iframes
  // ============================================================
  const AD_SCRIPT_PATTERNS = [
    'adxcontent', 'trafficstars', 'exoclick', 'exosrv', 'realsrv',
    'juicyads', 'popads', 'popcash', 'propellerads', 'tsyndicate',
    'hilltopads', 'clickadu', 'a-ads.com', 'padsdel',
    'googlesyndication', 'doubleclick', '-adx.js',
    '789club', '789.club',
    'zorvec',
    'onclickmax', 'onclicka', 'monetag', 'richads', 'pushground',
    'adsterra', 'adskeeper', 'bidvertiser', 'highcpmrevenue', 'galaksion',
    'pop-banner', 'popup.js', 'banner-ads', 'under-player-ads'
  ];

  // Intercept script/iframe src setter to block ad scripts  
  const origScriptSrcDesc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
  if (origScriptSrcDesc && origScriptSrcDesc.set) {
    Object.defineProperty(HTMLScriptElement.prototype, 'src', {
      set: function(val) {
        if (val && typeof val === 'string') {
          const lower = val.toLowerCase();
          for (let i = 0; i < AD_SCRIPT_PATTERNS.length; i++) {
            if (lower.includes(AD_SCRIPT_PATTERNS[i])) {
              return; // Block ad script load
            }
          }
        }
        return origScriptSrcDesc.set.call(this, val);
      },
      get: origScriptSrcDesc.get,
      configurable: true,
      enumerable: true
    });
  }

  // Intercept appendChild/insertBefore to block ad elements
  const origAppendChild = Node.prototype.appendChild;
  Node.prototype.appendChild = function(child) {
    if (child && child.tagName) {
      const tag = child.tagName.toUpperCase();
      if (tag === 'SCRIPT' || tag === 'IFRAME') {
        const src = child.src || child.getAttribute('src') || '';
        if (src) {
          const lower = src.toLowerCase();
          for (let i = 0; i < AD_SCRIPT_PATTERNS.length; i++) {
            if (lower.includes(AD_SCRIPT_PATTERNS[i])) {
              return child; // Block but pretend success
            }
          }
        }
      }
    }
    return origAppendChild.call(this, child);
  };

  const origInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function(newNode, refNode) {
    if (newNode && newNode.tagName) {
      const tag = newNode.tagName.toUpperCase();
      if (tag === 'SCRIPT' || tag === 'IFRAME') {
        const src = newNode.src || newNode.getAttribute('src') || '';
        if (src) {
          const lower = src.toLowerCase();
          for (let i = 0; i < AD_SCRIPT_PATTERNS.length; i++) {
            if (lower.includes(AD_SCRIPT_PATTERNS[i])) {
              return newNode;
            }
          }
        }
      }
    }
    return origInsertBefore.call(this, newNode, refNode);
  };

  // ============================================================
  // 0. JWPlayer / Video Player Ad Stripping
  //    Multiple strategies to remove pre-roll ads
  // ============================================================

  // Strategy 1: Intercept jQuery AJAX to strip ad config from /ajax/player response
  function patchJQueryAjax() {
    if (!window.jQuery && !window.$) return false;
    const jq = window.jQuery || window.$;
    if (!jq.ajax || jq.ajax._ndsPatched) return true;

    const origAjax = jq.ajax;
    jq.ajax = function(opts) {
      if (opts && typeof opts === 'object' && opts.url) {
        const url = opts.url.toLowerCase();
        if (url.includes('/ajax/player') || url.includes('/ajax/episode')) {
          const origSuccess = opts.success;
          opts.success = function(response) {
            if (typeof response === 'string') {
              // Strip advertising config from JWPlayer setup calls
              response = response.replace(/advertising\s*:\s*\{[^}]*\}/gi, '');
              response = response.replace(/adschedule\s*:\s*\{[^}]*\}/gi, '');
              response = response.replace(/adSchedule\s*:\s*\{[^}]*\}/gi, '');
              response = response.replace(/"advertising"\s*:\s*\{[^}]*\}/gi, '');
              response = response.replace(/"adschedule"\s*:\s*\{[^}]*\}/gi, '');
              // Remove VAST/VPAID URLs
              response = response.replace(/https?:\/\/[^\s"']*vast[^\s"']*/gi, '');
              response = response.replace(/https?:\/\/[^\s"']*vpaid[^\s"']*/gi, '');
              response = response.replace(/https?:\/\/[^\s"']*9922\.com[^\s"']*/gi, '');
            }
            if (origSuccess) return origSuccess.apply(this, [response]);
          };
        }
      }
      return origAjax.apply(this, arguments);
    };
    jq.ajax._ndsPatched = true;
    return true;
  }

  // Strategy 2: Override jwplayer function to strip ads from setup config
  function patchJWPlayerFunc() {
    if (typeof window.jwplayer !== 'function') return false;
    if (window.jwplayer._ndsWrapped) return true;

    const origJWP = window.jwplayer;
    const wrapper = function() {
      const inst = origJWP.apply(this, arguments);
      if (inst && !inst._ndsAdPatched) {
        // Patch setup
        if (inst.setup) {
          const origSetup = inst.setup;
          inst.setup = function(cfg) {
            if (cfg) {
              delete cfg.advertising;
              delete cfg.adschedule;
              delete cfg.adSchedule;
              delete cfg.ad;
              delete cfg.ads;
              if (cfg.playlist) {
                [].concat(cfg.playlist).forEach(function(p) {
                  if (p) { delete p.adschedule; delete p.adSchedule; }
                });
              }
            }
            return origSetup.call(inst, cfg);
          };
        }
        // Patch playAd to be a no-op  
        inst.playAd = function() {};
        inst._ndsAdPatched = true;
      }
      return inst;
    };
    // Copy all static properties
    for (var k in origJWP) {
      if (origJWP.hasOwnProperty(k)) {
        try { wrapper[k] = origJWP[k]; } catch(e) {}
      }
    }
    try { wrapper.key = origJWP.key; } catch(e) {}
    try { wrapper.version = origJWP.version; } catch(e) {}
    wrapper._ndsWrapped = true;
    wrapper._orig = origJWP;
    window.jwplayer = wrapper;
    return true;
  }

  // Strategy 3: Actively skip any playing ads via JWPlayer API
  function skipJWPlayerAds() {
    try {
      if (typeof window.jwplayer !== 'function') return;
      var p = window.jwplayer('player');
      if (!p || !p.getState) return;

      var state = p.getState();
      // Check if ad is playing
      if (p.getAdBlock) return; // Method doesn't exist but check anyway
      
      // Try to detect ad playing via JWPlayer API
      var container = document.getElementById('player');
      if (!container) return;

      // Check for JWPlayer ad elements
      var adPlaying = container.querySelector('.jw-ad-notice') ||
                      container.querySelector('.jw-ad-skip') ||
                      document.getElementById('skipad') ||
                      document.getElementById('adsmessage');
      
      if (adPlaying) {
        // Try various skip methods
        try { p.skipAd(); } catch(e) {}
        try { p.stopAd(); } catch(e) {}
        try {
          // Force play main content
          if (p.getPlaylistIndex && p.playlistItem) {
            p.playlistItem(p.getPlaylistIndex());
          }
        } catch(e) {}
        // Click skip button
        var skipBtn = document.getElementById('skipad') || 
                      container.querySelector('.jw-ad-skip') ||
                      container.querySelector('.jw-skipoffset') ||
                      container.querySelector('[class*="skip"]');
        if (skipBtn) skipBtn.click();
      }
    } catch(e) {}
  }

  // Run all strategies
  const patchInterval = setInterval(function() {
    patchJQueryAjax();
    patchJWPlayerFunc();
    skipJWPlayerAds();
  }, 200);
  setTimeout(function() { clearInterval(patchInterval); }, 30000);
  
  // Keep ad-skipping active longer
  setInterval(skipJWPlayerAds, 500);

  // ============================================================
  // 0.5. Anti-DevTools Detection Bypass
  //      Exact detection: Image() + Object.defineProperty(img,'id',{get:...})
  //      + console.dir(img) + setInterval + location.href = '/400.html'
  // ============================================================
  
  // Layer 1: Block Object.defineProperty from setting getter on Image's 'id'
  const origDefineProperty = Object.defineProperty;
  Object.defineProperty = function(obj, prop, descriptor) {
    // Block the exact detection pattern: Image instance + 'id' property + getter
    if (obj instanceof Image && prop === 'id' && descriptor && descriptor.get) {
      return obj; // Silently block - the getter trap is never set
    }
    return origDefineProperty.apply(Object, arguments);
  };

  // Layer 2: Override console.dir to skip Image objects entirely
  const origConsoleDir = console.dir;
  const origConsoleLog = console.log;
  console.dir = function() {
    if (arguments.length > 0 && arguments[0] instanceof Image) return;
    return origConsoleDir.apply(console, arguments);
  };

  // Layer 3: Intercept setInterval - block detection loops
  // Detection uses obfuscated vars like _0x9f10, so check for those patterns
  const origSetInterval2 = window.setInterval;
  window.setInterval = function(fn, delay) {
    if (typeof fn === 'function') {
      const fnStr = fn.toString();
      // Block functions that match DevTools detection patterns
      if (fnStr.includes('console') || fnStr.includes('_0x') || fnStr.includes('checkStatus')) {
        if (fnStr.includes('dir') || fnStr.includes('location') || fnStr.includes('400') || fnStr.includes('href')) {
          return origSetInterval2.call(window, function() {}, delay || 1000);
        }
      }
    }
    return origSetInterval2.apply(window, arguments);
  };

  // Layer 4: Block devtoolschange event listener
  const origWinAddListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type) {
    if (type === 'devtoolschange') return;
    return origWinAddListener.apply(this, arguments);
  };

  // Layer 5: Block navigation to /400.html using multiple methods
  // a) Override location methods
  try {
    const origAssign = window.location.assign.bind(window.location);
    window.location.assign = function(url) {
      if (typeof url === 'string' && url.includes('/400')) return;
      return origAssign(url);
    };
  } catch(e) {}
  try {
    const origReplace = window.location.replace.bind(window.location);
    window.location.replace = function(url) {
      if (typeof url === 'string' && url.includes('/400')) return;
      return origReplace(url);
    };
  } catch(e) {}

  // b) Use beforeunload to catch location.href = '/400.html' 
  window.addEventListener('beforeunload', function(e) {
    // Can't reliably block here, but we can use popstate
  });

  // c) Monitor and revert /400.html navigation  
  const origPushState = history.pushState;
  history.pushState = function() {
    if (arguments[2] && typeof arguments[2] === 'string' && arguments[2].includes('/400')) return;
    return origPushState.apply(history, arguments);
  };

  // Layer 6: Periodically check and remove Security Alert elements
  const removeSecurityAlert = function() {
    // Remove player_message with security alert content
    var pm = document.getElementById('player_message');
    if (pm && pm.innerHTML.length > 0) {
      pm.innerHTML = '';
      pm.style.display = 'none';
    }
    // Remove any element containing "Security alert" text
    document.querySelectorAll('div').forEach(function(div) {
      if (div.textContent && div.textContent.includes('Security alert') && div.textContent.includes('developer tools')) {
        div.remove();
      }
    });
  };
  setInterval(removeSecurityAlert, 300);


  // ============================================================
  // 1. Spoof ad-related global variables
  // ============================================================
  window.canRunAds = true;
  window.isAdBlockActive = false;
  window.adBlockEnabled = false;
  window.adBlockDetected = false;
  window.__ads = true;
  window.__adblock = false;
  window.addCompleted = true;
  window.google_ad_status = 1;

  // Google AdSense spoofing
  Object.defineProperty(window, 'adsbygoogle', {
    value: { loaded: true, push: function() {}, length: 0 },
    writable: false,
    configurable: true
  });

  // ============================================================
  // 2. Override fetch() to fake responses for detection URLs
  //    Detection scripts fetch ad URLs and check if they fail
  // ============================================================
  const origFetch = window.fetch;
  window.fetch = function(input, init) {
    const url = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
    const urlLower = url.toLowerCase();

    // Known anti-adblock detection fetch targets
    const isDetectionUrl = (
      urlLower.includes('adblockanalytics.com') ||
      urlLower.includes('adblockdetect') ||
      urlLower.includes('pagead2.googlesyndication.com') ||
      urlLower.includes('pagead/js/adsbygoogle') ||
      urlLower.includes('doubleclick.net') ||
      urlLower.includes('googleadservices.com') ||
      urlLower.includes('fundingchoicesmessages') ||
      urlLower.includes('adserver') ||
      urlLower.includes('/adblock/')
    );

    if (isDetectionUrl) {
      // Return a fake opaque response (no-cors mode returns opaque)
      const mode = (init && init.mode) || '';
      if (mode === 'no-cors') {
        return Promise.resolve(new Response('', { status: 0, statusText: '' }));
      }
      // For regular requests, return a fake 200
      return Promise.resolve(new Response('', { 
        status: 200, 
        statusText: 'OK',
        headers: new Headers({ 'Content-Type': 'text/javascript' })
      }));
    }

    return origFetch.apply(this, arguments);
  };

  // ============================================================
  // 3. Override XMLHttpRequest for detection URLs
  // ============================================================
  const origXHROpen = XMLHttpRequest.prototype.open;
  const origXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url) {
    this._url = url;
    return origXHROpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function() {
    const url = (this._url || '').toLowerCase();
    const isDetectionUrl = (
      url.includes('adblockanalytics') ||
      url.includes('adblockdetect') ||
      url.includes('pagead2.googlesyndication') ||
      url.includes('/adblock/')
    );

    if (isDetectionUrl) {
      Object.defineProperty(this, 'status', { value: 200, writable: false });
      Object.defineProperty(this, 'readyState', { value: 4, writable: false });
      Object.defineProperty(this, 'responseText', { value: '', writable: false });
      setTimeout(() => {
        if (this.onload) this.onload();
        if (this.onreadystatechange) this.onreadystatechange();
      }, 10);
      return;
    }

    return origXHRSend.apply(this, arguments);
  };

  // ============================================================
  // 4. Override script element creation to fake ad script loading
  //    Detection creates <script src="adblockanalytics.com/..."> 
  //    and checks onload vs onerror
  // ============================================================
  const origCreateElement = document.createElement.bind(document);
  
  document.createElement = function(tagName) {
    const el = origCreateElement(tagName);

    // Block dynamically created anchors used for popunders
    if (tagName.toLowerCase() === 'a') {
      const origClick = el.click;
      el.click = function() {
        const href = (el.href || '').toLowerCase();
        if (el.target === '_blank' && href && !href.includes(window.location.hostname)) {
          return;
        }
        return origClick.call(el);
      };
    }

    if (tagName.toLowerCase() === 'script') {
      // Watch for src being set
      const origSrcDescriptor = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src') ||
                                 Object.getOwnPropertyDescriptor(el.__proto__, 'src');
      
      let _fakeSrc = '';
      
      Object.defineProperty(el, 'src', {
        get() {
          return _fakeSrc || (origSrcDescriptor ? origSrcDescriptor.get.call(this) : '');
        },
        set(value) {
          if (typeof value !== 'string') {
            if (origSrcDescriptor && origSrcDescriptor.set) origSrcDescriptor.set.call(this, value);
            return;
          }
          _fakeSrc = value;
          const urlLower = value.toLowerCase();
          const isDetectionScript = (
            urlLower.includes('adblockanalytics.com') ||
            urlLower.includes('adblockdetect') ||
            urlLower.includes('adserver') ||
            urlLower.includes('pagead2.googlesyndication') ||
            urlLower.includes('doubleclick.net') ||
            urlLower.includes('googleadservices') ||
            urlLower.includes('google-adsense') ||
            urlLower.includes('adsbygoogle') ||
            urlLower.includes('fundingchoices')
          );

          if (isDetectionScript) {
            // Don't set the real src - fake a successful load
            setTimeout(() => {
              if (this.onload) this.onload();
              this.dispatchEvent(new Event('load'));
            }, 50);
            return;
          }

          // Set real src for non-detection scripts
          if (origSrcDescriptor && origSrcDescriptor.set) {
            origSrcDescriptor.set.call(this, value);
          } else {
            this.setAttribute('src', value);
          }
        },
        configurable: true
      });
    }

    return el;
  };

  // Also copy over any static methods
  for (const key of Object.getOwnPropertyNames(Document.prototype.createElement)) {
    try {
      if (key !== 'length' && key !== 'name') {
        document.createElement[key] = Document.prototype.createElement[key];
      }
    } catch(e) {}
  }

  // ============================================================
  // 5. Override Image loading for detection images
  //    Detection loads images with ad-like names and checks onerror
  // ============================================================
  const OrigImage = window.Image;
  window.Image = function(width, height) {
    const img = new OrigImage(width, height);
    
    const origSrcDesc = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    let _imgFakeSrc = '';
    
    Object.defineProperty(img, 'src', {
      get() {
        return _imgFakeSrc || (origSrcDesc ? origSrcDesc.get.call(this) : '');
      },
      set(value) {
        if (typeof value !== 'string') {
          if (origSrcDesc && origSrcDesc.set) origSrcDesc.set.call(this, value);
          return;
        }
        _imgFakeSrc = value;
        const urlLower = value.toLowerCase();
        const isDetectionImage = (
          urlLower.includes('adblockanalytics.com') ||
          urlLower.includes('ad_728') ||
          urlLower.includes('ad_top') ||
          urlLower.includes('ad_bottom') ||
          urlLower.includes('ad-choice') ||
          urlLower.includes('ad-choices') ||
          (urlLower.includes('ad_') && (urlLower.endsWith('.jpg') || urlLower.endsWith('.png') || urlLower.endsWith('.gif')))
        );

        if (isDetectionImage) {
          // Fake successful load
          setTimeout(() => {
            Object.defineProperty(this, 'naturalWidth', { value: 1, configurable: true });
            Object.defineProperty(this, 'naturalHeight', { value: 1, configurable: true });
            Object.defineProperty(this, 'complete', { value: true, configurable: true });
            if (this.onload) this.onload();
          }, 30);
          return;
        }

        if (origSrcDesc && origSrcDesc.set) {
          origSrcDesc.set.call(this, value);
        }
      },
      configurable: true
    });

    return img;
  };
  window.Image.prototype = OrigImage.prototype;

  // ============================================================
  // 6. Override element dimension getters for bait elements
  //    Detection creates tiny divs with ad class names and
  //    checks if they have height/width = 0 (hidden by adblocker)
  // ============================================================
  
  function isBaitElement(el) {
    if (!el || !el.className || typeof el.className !== 'string') return false;
    const cls = el.className.toLowerCase();
    return (cls.includes('ad-banner') || cls.includes('ad-unit') || 
            cls.includes('ad-placeholder') || cls.includes('adsbox') ||
            cls.includes('adsbygoogle') || cls.includes('doubleclick') ||
            cls.includes('advert') || cls.includes('ad-choice'));
  }

  // Override clientHeight
  const origClientHeight = Object.getOwnPropertyDescriptor(Element.prototype, 'clientHeight');
  if (origClientHeight) {
    Object.defineProperty(Element.prototype, 'clientHeight', {
      get() {
        const val = origClientHeight.get.call(this);
        return (val === 0 && isBaitElement(this)) ? 1 : val;
      },
      configurable: true
    });
  }

  // Override clientWidth
  const origClientWidth = Object.getOwnPropertyDescriptor(Element.prototype, 'clientWidth');
  if (origClientWidth) {
    Object.defineProperty(Element.prototype, 'clientWidth', {
      get() {
        const val = origClientWidth.get.call(this);
        return (val === 0 && isBaitElement(this)) ? 1 : val;
      },
      configurable: true
    });
  }

  // Override offsetHeight
  const origOffsetHeight = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetHeight');
  if (origOffsetHeight) {
    Object.defineProperty(HTMLElement.prototype, 'offsetHeight', {
      get() {
        const val = origOffsetHeight.get.call(this);
        return (val === 0 && isBaitElement(this)) ? 1 : val;
      },
      configurable: true
    });
  }

  // Override offsetWidth
  const origOffsetWidth = Object.getOwnPropertyDescriptor(HTMLElement.prototype, 'offsetWidth');
  if (origOffsetWidth) {
    Object.defineProperty(HTMLElement.prototype, 'offsetWidth', {
      get() {
        const val = origOffsetWidth.get.call(this);
        return (val === 0 && isBaitElement(this)) ? 1 : val;
      },
      configurable: true
    });
  }

  // ============================================================
  // 7. Override getComputedStyle for bait elements
  // ============================================================
  const origGetComputedStyle = window.getComputedStyle;
  window.getComputedStyle = function(element, pseudoElt) {
    const style = origGetComputedStyle.call(window, element, pseudoElt);
    
    if (element && isBaitElement(element)) {
      return new Proxy(style, {
        get(target, prop) {
          if (prop === 'display') return 'block';
          if (prop === 'visibility') return 'visible';
          if (prop === 'opacity') return '1';
          if (prop === 'height') return '1px';
          if (prop === 'width') return '1px';
          if (prop === 'getPropertyValue') {
            return function(name) {
              if (name === 'display') return 'block';
              if (name === 'visibility') return 'visible';
              return target.getPropertyValue(name);
            };
          }
          const value = Reflect.get(target, prop);
          return typeof value === 'function' ? value.bind(target) : value;
        }
      });
    }
    return style;
  };

  // ============================================================
  // 8. Create bait divs that detection scripts look for
  // ============================================================
  function createBaitDivs() {
    if (!document.body) return; // Body not ready yet
    
    const baitIds = [
      'nqoybpxnanylgvpfpbz',
      'UpxrGeuXbjCK',
    ];

    baitIds.forEach(id => {
      if (!document.getElementById(id)) {
        const el = origCreateElement('div');
        el.id = id;
        el.style.display = 'none';
        document.body.appendChild(el);
      }
    });
  }

  // ============================================================
  // 9. Intercept the detection result POST to /ztdzab/
  //    Spoof it to report "no adblock" (ifm=a means no adblock)
  // ============================================================
  const origFetchRef = origFetch; // Use the original un-patched fetch
  const patchedFetch = window.fetch;
  
  window.fetch = function(input, init) {
    const url = (typeof input === 'string') ? input : (input && input.url ? input.url : '');
    
    // Intercept the detection result POST
    if (url.includes('/ztdzab/') && init && init.method && init.method.toUpperCase() === 'POST') {
      // Change the body to report "no adblock detected"
      // ifm=a means no adblock, ifm=b means adblock detected
      // p=6 means all 6 checks passed, f=0 means 0 failed
      const newBody = 'ifm=a&p=6&f=0';
      const newInit = Object.assign({}, init, { body: newBody });
      return origFetchRef.apply(this, [input, newInit]);
    }

    return patchedFetch.apply(this, arguments);
  };

  // ============================================================
  // 10. Remove anti-adblock overlays/walls
  // ============================================================
  function removeAntiAdblockWalls() {
    const wallSelectors = [
      '[class*="adblock-notice"]', '[class*="adblock-warning"]',
      '[class*="adblock-modal"]', '[class*="adblock-overlay"]',
      '[class*="adb-overlay"]', '[class*="disable-adblock"]',
      '[id*="adblock-notice"]', '[id*="adblock-modal"]',
      '[id*="adblock-overlay"]',
    ];

    wallSelectors.forEach(sel => {
      document.querySelectorAll(sel).forEach(el => el.remove());
    });

    // Restore body scroll
    if (document.body) {
      const bs = document.body.style;
      if (bs.overflow === 'hidden' && document.querySelector('[class*="adblock"], [id*="adblock"]')) {
        bs.overflow = '';
        bs.position = '';
      }
    }
  }

  // ============================================================
  // 11. Run on page ready
  // ============================================================
  function onReady() {
    createBaitDivs();
    removeAntiAdblockWalls();
    // Re-run periodically
    setTimeout(createBaitDivs, 500);
    setTimeout(createBaitDivs, 2000);
    setTimeout(removeAntiAdblockWalls, 1000);
    setTimeout(removeAntiAdblockWalls, 3000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onReady);
  } else {
    onReady();
  }

  // Also on full load
  window.addEventListener('load', () => {
    setTimeout(onReady, 100);
    setTimeout(onReady, 1000);
  });

  // MutationObserver for anti-adblock walls
  const wallObs = new MutationObserver(() => {
    removeAntiAdblockWalls();
    createBaitDivs();
  });

  if (document.documentElement) {
    wallObs.observe(document.documentElement, { childList: true, subtree: true });
  }

  // ============================================================
  // 12. YouTube Speed Controller (MAIN world)
  //     Receives speed commands from content.js via postMessage
  // ============================================================
  
  let _ndsOrigPlaybackRate = null;

  function setYouTubeSpeed(speed) {
    try {
      const v = document.querySelector('video');
      if (!v) return;

      // Save original playbackRate descriptor once
      if (!_ndsOrigPlaybackRate) {
        _ndsOrigPlaybackRate = Object.getOwnPropertyDescriptor(
          HTMLMediaElement.prototype, 'playbackRate'
        );
      }
      const orig = _ndsOrigPlaybackRate;
      if (!orig) return;

      if (speed > 2) {
        // For speeds > 2x: override playbackRate property
        // YouTube's ratechange handler reads video.playbackRate and resets if > max
        // We make the getter report 2 so YouTube thinks it's fine
        
        // First, set the REAL speed
        orig.set.call(v, speed);

        // Override the property to fool YouTube
        Object.defineProperty(v, 'playbackRate', {
          get: function() { return 2; }, // Lie to YouTube: report 2x
          set: function(val) {
            // If YouTube tries to set it to 2 or 1 (reset), ignore
            if (val <= 2) return;
            // If it's our own call, allow through
            orig.set.call(v, val);
          },
          configurable: true,
          enumerable: true
        });

        // Force set the real speed underneath
        orig.set.call(v, speed);

      } else {
        // For speeds <= 2x: restore original behavior
        try {
          delete v.playbackRate; // Remove instance override
        } catch(e) {}
        
        // If delete didn't work, restore descriptor
        try {
          Object.defineProperty(v, 'playbackRate', orig);
        } catch(e) {}

        v.playbackRate = speed;

        // Also try YouTube's internal player API
        const p = document.getElementById('movie_player');
        if (p && p.setPlaybackRate) {
          try { p.setPlaybackRate(speed); } catch(e) {}
        }
      }
    } catch(e) {
      // Fallback
      const v = document.querySelector('video');
      if (v) v.playbackRate = speed;
    }
  }

  // Listen for speed commands from content.js
  window.addEventListener('message', function(event) {
    if (event.source !== window) return;
    if (event.data && event.data.type === 'NDS_SET_SPEED') {
      setYouTubeSpeed(event.data.speed);
    }
  });

})();
