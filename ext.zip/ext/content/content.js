// ============================================================
// NextDNS Shield - Content Script (Cosmetic Filtering)
// Enhanced with YouTube Ad Blocking
// ============================================================

(function() {
  'use strict';

  // Ad-related selectors to detect and hide
  const AD_SELECTORS = [
    'iframe[src*="doubleclick"]',
    'iframe[src*="googlesyndication"]',
    'iframe[src*="googleadservices"]',
    'iframe[src*="amazon-adsystem"]',
    'iframe[src*="facebook.com/plugins"]',
    'iframe[src*="ad."]',
    'iframe[src*="/ads/"]',
    'iframe[src*="/ad/"]',
    'iframe[id*="google_ads"]',
    'iframe[name*="google_ads"]',
    '[id*="AdSlot"]',
    '[id*="adslot"]',
    '[class*="dfp-ad"]',
    '[class*="js-ad"]',
    '[class*="ad-placement"]',
    '[class*="ad-position"]',
    '[class*="sticky-ad"]',
    '[class*="stickyAd"]',
    '[class*="floating-ad"]',
    '[data-google-query-id]',
    '[data-ad-manager-id]',
    '[data-dfp]',
    '[data-spotim-module="ads"]',
    '.adthrive-ad',
    '.ezoic-ad',
    '.mediavine-ad',
    '#carbonads',
    '.carbon-wrap',
    // Vietnamese movie sites (rophim, phimmoi, etc.)
    '#overlay',
    '#mobileCatfish',
    '#mobileCatfish_pc',
    '.ads-catfish',
    '.ads-top',
    '.ads-top-mobile',
    '.ads-list',
    '.ads-ul-center',
    '[class*="ads-catfish"]',
    'div[id="banner"]',
    '.main-top-ads',
    'a[href*="phimbet.net"]',
    'a[href*="f8bet.ink"]',
    'a[href*="bdvn.com/tracker"]',
    'a[href*="154.82.109.168"]',
    'a[href*="i9.top"]',
    'a[href*="i9bet"]',
    'img[src*="demo_banner"]',
    'img[alt="vip66"]',
    'img[alt="xoso66"]',
    'img[alt="i9bet"]',
    'img[alt="bdvn"]',
    // VLXX / Adult sites
    '#vl-header-adx',
    '#vl-native-adx',
    '#vl-main-adx',
    '#vl-footer-adx',
    '#vl-sidebar-adx',
    '#vl-video-adx',
    '#vl-underplayer-adx',
    '#adx',
    'div[id*="-adx"]',
    'div[id*="_adx"]',
    'iframe[src*="adxcontent"]',
    'iframe[src*="trafficstars"]',
    'iframe[src*="exosrv"]',
    'iframe[src*="realsrv"]',
    // 789club gambling
    'a[href*="789club"]',
    'a[href*="789.club"]',
    'img[src*="789"]',
    'img[alt*="789"]',
    '#adx',
    // Gambling brand banners (xnhau, etc.)
    'a[href*="cm88"]',
    'a[href*="c168"]',
    'a[href*="new88"]',
    'a[href*="qq88"]',
    'a[href*="sv388"]',
    'a[href*="go88"]',
    'a[href*="jun88"]',
    'a[href*="sin88"]',
    'a[href*="kubet"]',
    'a[href*="sunwin"]',
    'a[href*="luck8"]',
    'a[href*="typhu88"]',
    'a[href*="hi88"]',
    'a[href*="shbet"]',
    'a[href*="ae888"]',
    'a[href*="fun88"]',
    'a[href*="oxbet"]',
    'a[href*="debet"]',
    'a[href*="bong88"]',
    'a[href*="vn88"]',
    'img[src*="cm88"]',
    'img[src*="c168"]',
    'img[src*="new88"]',
    'img[src*="qq88"]',
    // Standard banner sizes (728x90, 300x250)
    'a[target="_blank"] > img[width="728"]',
    'a[target="_blank"] > img[height="90"]',
    'a[target="_blank"] > img[width="300"][height="250"]',
    // Video ad banners
    'video.center-ad',
    '.center-ad',
    'a[href*="bit.ly"]',
    'a[href*="bitly."]',
    'video[src*="xnhau.blog"]',
    'source[src*="xnhau.blog"]',
    'source[src*="c168"]',
    'source[src*="cm88"]',
    'source[src*="new88"]',
    // Catfish / sticky overlay ads
    '[id*="catfish"]',
    '[class*="catfish"]',
    '[onclick*="closeAd"]',
    '.close-btn[onclick*="catfish"]',
  ];

  let hiddenCount = 0;

  // Check if extension is enabled and page is not whitelisted
  async function shouldFilter() {
    try {
      const settings = await chrome.storage.local.get(['enabled', 'cosmeticFiltering', 'whitelist']);
      if (settings.enabled === false || settings.cosmeticFiltering === false) return false;
      const whitelist = settings.whitelist || [];
      const hostname = window.location.hostname;
      if (whitelist.some(domain => hostname === domain || hostname.endsWith('.' + domain))) return false;
      return true;
    } catch {
      return true;
    }
  }

  // Hide an element (skip bait elements used by anti-adblock detection)
  function hideElement(el) {
    if (el.dataset.nextdnsHidden) return;
    if (el.dataset.nextdnsBait) return; // Protected by anti-detect.js
    
    // Detect bait elements: tiny, off-screen, used for adblock detection
    const rect = el.getBoundingClientRect();
    const style = el.getAttribute('style') || '';
    const isBait = (
      (rect.width <= 2 && rect.height <= 2 && rect.width > 0) ||
      style.includes('-10000px') ||
      (el.offsetWidth <= 1 && el.offsetHeight <= 1 && el.offsetWidth > 0)
    );
    if (isBait) return; // Don't hide bait elements
    
    el.style.setProperty('display', 'none', 'important');
    el.style.setProperty('visibility', 'hidden', 'important');
    el.style.setProperty('height', '0', 'important');
    el.style.setProperty('min-height', '0', 'important');
    el.style.setProperty('overflow', 'hidden', 'important');
    el.dataset.nextdnsHidden = 'true';
    hiddenCount++;
  }

  // Scan and hide ad elements
  function scanAndHide() {
    const selector = AD_SELECTORS.join(', ');
    document.querySelectorAll(selector).forEach(hideElement);
    
    // Remove popunder tracking attributes (data-rt is used by xnhau.vc for popunder targeting)
    document.querySelectorAll('[data-rt]').forEach(el => {
      el.removeAttribute('data-rt');
    });
    
    // Remove onclick handlers from all links that might trigger popunders
    document.querySelectorAll('a[onclick]').forEach(a => {
      const onclick = (a.getAttribute('onclick') || '').toLowerCase();
      if (onclick.includes('open') || onclick.includes('window') || onclick.includes('location')) {
        a.removeAttribute('onclick');
      }
    });
    
    // Deep scan for gambling banners served from site's own domain
    scanGamblingBanners();
  }

  // Gambling brand keywords to detect in img src/alt and link href
  const GAMBLING_KEYWORDS = [
    'cm88', 'c168', 'new88', 'qq88', '789club', '789.club', 'sv388',
    'go88', 'jun88', 'sin88', 'kubet', 'sunwin', 'luck8', 'typhu88',
    'hi88', 'shbet', 'ae888', 'fun88', 'oxbet', 'debet', 'bong88',
    'vn88', 'may88', 'mb66', 'i9bet', 'ta88', 'yo88', 'b52',
    'iwin68', 'nohu', 'dagacuoc', 'bet88', 'w88', '188bet',
    'hbet', 'lu88', 'gbong', 'xibet', 'usbet', 'k88', 'man88'
  ];

  // Don't hide major page containers
  function isMajorContainer(el) {
    if (!el) return true;
    const tag = el.tagName;
    if (tag === 'BODY' || tag === 'HTML' || tag === 'MAIN' || tag === 'ARTICLE' || tag === 'SECTION') return true;
    const id = (el.id || '').toLowerCase();
    const cls = (el.className || '').toLowerCase();
    if (id.includes('player') || id.includes('video') || id.includes('content') || id.includes('main') || id.includes('wrapper')) return true;
    if (cls.includes('player') || cls.includes('video-') || cls.includes('content') || cls.includes('container') || cls.includes('wrapper') || cls.includes('page')) return true;
    return false;
  }

  function scanGamblingBanners() {
    // Scan all images - check src, alt, title, data-src for keywords
    document.querySelectorAll('img').forEach(img => {
      const src = (img.src || '').toLowerCase();
      const alt = (img.alt || '').toLowerCase();
      const title = (img.title || '').toLowerCase();
      const dataSrc = (img.getAttribute('data-src') || img.getAttribute('data-original') || img.getAttribute('data-lazy-src') || '').toLowerCase();
      const matched = GAMBLING_KEYWORDS.some(kw => src.includes(kw) || alt.includes(kw) || title.includes(kw) || dataSrc.includes(kw));
      if (matched) {
        hideElement(img);
        // Only hide parent <a> tag, not grandparent containers
        const parent = img.closest('a');
        if (parent) hideElement(parent);
      }
    });

    // Scan ALL elements for background-image containing gambling keywords
    document.querySelectorAll('div, span, section, aside, a').forEach(el => {
      const bg = (el.style.backgroundImage || '').toLowerCase();
      const style = (el.getAttribute('style') || '').toLowerCase();
      if (bg || style.includes('background')) {
        const bgStr = bg + ' ' + style;
        const matched = GAMBLING_KEYWORDS.some(kw => bgStr.includes(kw));
        if (matched) {
          hideElement(el);
        }
      }
    });

    // Scan all links for gambling hrefs
    document.querySelectorAll('a').forEach(a => {
      const href = (a.href || '').toLowerCase();
      const matched = GAMBLING_KEYWORDS.some(kw => href.includes(kw));
      if (matched) {
        hideElement(a);
      }
    });

    // Visual scan: hide large banner images by rendered size
    document.querySelectorAll('img').forEach(img => {
      const rect = img.getBoundingClientRect();
      const w = rect.width;
      const h = rect.height;
      if (w === 0 || h === 0) return;
      const isBannerSize = (
        (w >= 700 && h >= 70 && h <= 120) ||
        (w >= 460 && h >= 50 && h <= 70) ||
        (w >= 290 && w <= 340 && h >= 240 && h <= 260) ||
        (w >= 950 && h >= 80 && h <= 260)
      );
      if (isBannerSize) {
        const parent = img.closest('a');
        if (parent && parent.hostname !== window.location.hostname) {
          hideElement(img);
          hideElement(parent);
        }
      }
    });

    // External link images
    document.querySelectorAll('a > img, a[target="_blank"] > img').forEach(img => {
      const a = img.closest('a');
      if (!a) return;
      const href = (a.href || '').toLowerCase();
      if (href.includes(window.location.hostname)) return;
      const rect = img.getBoundingClientRect();
      if (rect.width > 200 && rect.height > 40) {
        hideElement(img);
        hideElement(a);
      }
    });

    // Scan video ad banners - only hide the ad video+link, NOT parent containers
    document.querySelectorAll('video, source').forEach(el => {
      const src = (el.src || el.getAttribute('src') || '').toLowerCase();
      const cls = (el.className || '').toLowerCase();
      const matched = GAMBLING_KEYWORDS.some(kw => src.includes(kw)) || 
                      cls.includes('center-ad') || cls.includes('ad-video') ||
                      src.includes('xnhau.blog');
      if (matched) {
        hideElement(el);
        // Only walk up to the parent <a> link, stop at major containers
        let p = el.parentElement;
        for (let i = 0; i < 2 && p; i++) {
          if (isMajorContainer(p)) break;
          if (p.tagName === 'A' || p.classList.contains('center-ad')) {
            hideElement(p);
          }
          p = p.parentElement;
        }
      }
    });

    // Scan all links to bit.ly
    document.querySelectorAll('a[href*="bit.ly"], a[href*="bitly."]').forEach(a => {
      hideElement(a);
    });
  }

  // Delayed re-scans to catch lazy-loaded banners
  setTimeout(() => scanGamblingBanners(), 2000);
  setTimeout(() => scanGamblingBanners(), 5000);
  setTimeout(() => scanGamblingBanners(), 10000);



  // Check if an element looks like an ad by its dimensions
  function looksLikeAd(el) {
    const rect = el.getBoundingClientRect();
    const adSizes = [
      [728, 90], [300, 250], [336, 280], [320, 50], [320, 100],
      [160, 600], [300, 600], [970, 90], [970, 250], [468, 60],
    ];
    const tolerance = 5;
    return adSizes.some(([w, h]) =>
      Math.abs(rect.width - w) < tolerance && Math.abs(rect.height - h) < tolerance
    );
  }

  // Smart detection for dynamically loaded ads
  function checkNewElement(el) {
    if (!(el instanceof HTMLElement)) return;
    if (el.dataset.nextdnsHidden) return;
    const selector = AD_SELECTORS.join(', ');
    if (el.matches && el.matches(selector)) {
      hideElement(el);
      return;
    }
    el.querySelectorAll(selector).forEach(hideElement);
    if (el.tagName === 'IFRAME' && looksLikeAd(el)) {
      const src = el.src || '';
      if (!src.includes(window.location.hostname)) {
        hideElement(el);
      }
    }
  }

  // MutationObserver for dynamically inserted ads
  function observeDOM() {
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            checkNewElement(node);
          }
        }
      }
      // Also re-scan for gambling banners on DOM changes
      scanGamblingBanners();
    });
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
    return observer;
  }

  // ============================================================
  // YouTube Ad Blocker
  // ============================================================
  const isYouTube = window.location.hostname === 'www.youtube.com' ||
                    window.location.hostname === 'youtube.com' ||
                    window.location.hostname === 'm.youtube.com';

  // ============================================================
  // YouTube Premium Logo Replacement
  // ============================================================
  const YT_PREMIUM_LOGO_SVG = `<svg xmlns="http://www.w3.org/2000/svg" class="external-icon" width="101" height="20" viewBox="0 0 101 20" focusable="false" aria-hidden="true" style="pointer-events: none; display: inherit; width: 100%; height: 100%;">
  <g>
    <path d="M14.4848 20C14.4848 20 23.5695 20 25.8229 19.4C27.0917 19.06 28.0459 18.08 28.3808 16.87C29 14.65 29 9.98 29 9.98C29 9.98 29 5.34 28.3808 3.14C28.0459 1.9 27.0917 0.94 25.8229 0.61C23.5695 0 14.4848 0 14.4848 0C14.4848 0 5.42037 0 3.17711 0.61C1.9286 0.94 0.954148 1.9 0.59888 3.14C0 5.34 0 9.98 0 9.98C0 9.98 0 14.65 0.59888 16.87C0.954148 18.08 1.9286 19.06 3.17711 19.4C5.42037 20 14.4848 20 14.4848 20Z" fill="#FF0033"></path>
    <path d="M19 10L11.5 5.75V14.25L19 10Z" fill="white"></path>
  </g>
  <g>
    <path d="M32.1819 2.10016V18.9002H34.7619V12.9102H35.4519C38.8019 12.9102 40.5619 11.1102 40.5619 7.57016V6.88016C40.5619 3.31016 39.0019 2.10016 35.7219 2.10016H32.1819ZM37.8619 7.63016C37.8619 10.0002 37.1419 11.0802 35.4019 11.0802H34.7619V3.95016H35.4519C37.4219 3.95016 37.8619 4.76016 37.8619 7.13016V7.63016Z"></path>
    <path d="M41.982 18.9002H44.532V10.0902C44.952 9.37016 45.992 9.05016 47.302 9.32016L47.462 6.33016C47.292 6.31016 47.142 6.29016 47.002 6.29016C45.802 6.29016 44.832 7.20016 44.342 8.86016H44.162L43.952 6.54016H41.982V18.9002Z"></path>
    <path d="M55.7461 11.5002C55.7461 8.52016 55.4461 6.31016 52.0161 6.31016C48.7861 6.31016 48.0661 8.46016 48.0661 11.6202V13.7902C48.0661 16.8702 48.7261 19.1102 51.9361 19.1102C54.4761 19.1102 55.7861 17.8402 55.6361 15.3802L53.3861 15.2602C53.3561 16.7802 53.0061 17.4002 51.9961 17.4002C50.7261 17.4002 50.6661 16.1902 50.6661 14.3902V13.5502H55.7461V11.5002ZM51.9561 7.97016C53.1761 7.97016 53.2661 9.12016 53.2661 11.0702V12.0802H50.6661V11.0702C50.6661 9.14016 50.7461 7.97016 51.9561 7.97016Z"></path>
    <path d="M60.1945 18.9002V8.92016C60.5745 8.39016 61.1945 8.07016 61.7945 8.07016C62.5645 8.07016 62.8445 8.61016 62.8445 9.69016V18.9002H65.5045L65.4845 8.93016C65.8545 8.37016 66.4845 8.04016 67.1045 8.04016C67.7745 8.04016 68.1445 8.61016 68.1445 9.69016V18.9002H70.8045V9.49016C70.8045 7.28016 70.0145 6.27016 68.3445 6.27016C67.1845 6.27016 66.1945 6.69016 65.2845 7.67016C64.9045 6.76016 64.1545 6.27016 63.0845 6.27016C61.8745 6.27016 60.7345 6.79016 59.9345 7.76016H59.7845L59.5945 6.54016H57.5445V18.9002H60.1945Z"></path>
    <path d="M74.0858 4.97016C74.9858 4.97016 75.4058 4.67016 75.4058 3.43016C75.4058 2.27016 74.9558 1.91016 74.0858 1.91016C73.2058 1.91016 72.7758 2.23016 72.7758 3.43016C72.7758 4.67016 73.1858 4.97016 74.0858 4.97016ZM72.8658 18.9002H75.3958V6.54016H72.8658V18.9002Z"></path>
    <path d="M79.9516 19.0902C81.4116 19.0902 82.3216 18.4802 83.0716 17.3802H83.1816L83.2916 18.9002H85.2816V6.54016H82.6416V16.4702C82.3616 16.9602 81.7116 17.3202 81.1016 17.3202C80.3316 17.3202 80.0916 16.7102 80.0916 15.6902V6.54016H77.4616V15.8102C77.4616 17.8202 78.0416 19.0902 79.9516 19.0902Z"></path>
    <path d="M90.0031 18.9002V8.92016C90.3831 8.39016 91.0031 8.07016 91.6031 8.07016C92.3731 8.07016 92.6531 8.61016 92.6531 9.69016V18.9002H95.3131L95.2931 8.93016C95.6631 8.37016 96.2931 8.04016 96.9131 8.04016C97.5831 8.04016 97.9531 8.61016 97.9531 9.69016V18.9002H100.613V9.49016C100.613 7.28016 99.8231 6.27016 98.1531 6.27016C96.9931 6.27016 96.0031 6.69016 95.0931 7.67016C94.7131 6.76016 93.9631 6.27016 92.8931 6.27016C91.6831 6.27016 90.5431 6.79016 89.7431 7.76016H89.5931L89.4031 6.54016H87.3531V18.9002H90.0031Z"></path>
  </g>
</svg>`;

  function replaceYouTubeLogo() {
    if (!isYouTube) return;

    // Find all YouTube logo SVGs (regular, non-premium)
    // Regular YT logo SVG has width=93, Premium has width=101
    const logoContainers = document.querySelectorAll('ytd-logo #logo-icon .yt-icon-shape div, a#logo .yt-icon-shape div, #start ytd-logo .yt-icon-shape div');
    
    logoContainers.forEach(container => {
      const svg = container.querySelector('svg');
      if (!svg) return;
      
      // Check if it's the regular YouTube logo (width 93) and not already replaced
      const width = svg.getAttribute('width');
      if (width === '93' && !container.dataset.premiumReplaced) {
        container.innerHTML = YT_PREMIUM_LOGO_SVG;
        container.dataset.premiumReplaced = 'true';
      }
    });

    // Also check for the direct SVG approach
    document.querySelectorAll('svg[id^="yt-ringo2-svg"]').forEach(svg => {
      const parent = svg.parentElement;
      if (parent && !parent.dataset.premiumReplaced) {
        parent.innerHTML = YT_PREMIUM_LOGO_SVG;
        parent.dataset.premiumReplaced = 'true';
      }
    });
  }

  const YT_AD_SELECTORS = [
    '.ytp-ad-overlay-container',
    '.ytp-ad-overlay-slot',
    '.ytp-ad-text-overlay',
    '.ytp-ad-image-overlay',
    '.ytp-ad-module',
    '.ytp-ad-player-overlay',
    '.ytp-ad-player-overlay-instream-info',
    '.ytp-ad-action-interstitial',
    '.ytp-ad-action-interstitial-background-container',
    '.ytp-ad-image-companion',
    '.ytp-ad-feedback-dialog-container',
    '.ytp-ad-preview-container',
    '#companion',
    '#player-ads',
    '#masthead-ad',
    'ytd-promoted-sparkles-web-renderer',
    'ytd-display-ad-renderer',
    'ytd-in-feed-ad-layout-renderer',
    'ytd-ad-slot-renderer',
    'ytd-banner-promo-renderer',
    'ytd-statement-banner-renderer',
    'ytd-search-pyv-renderer',
    'ytd-promoted-sparkles-text-search-renderer',
    'ytd-compact-promoted-video-renderer',
    'ytd-promoted-video-renderer',
    'ytd-mealbar-promo-renderer',
    'ytd-primetime-promo-renderer',
  ];

  // Skip/fast-forward video ads
  function skipVideoAd() {
    const player = document.querySelector('.html5-video-player');
    if (!player) return false;

    const isAdPlaying = player.classList.contains('ad-showing') ||
                        player.classList.contains('ad-interrupting');
    if (!isAdPlaying) return false;

    const video = player.querySelector('video');
    if (!video) return false;

    // Try all known skip button selectors
    const skipSelectors = [
      '.ytp-ad-skip-button',
      '.ytp-ad-skip-button-modern',
      '.ytp-skip-ad-button',
      'button.ytp-ad-skip-button',
      'button.ytp-ad-skip-button-modern',
      '.ytp-ad-skip-button-container button',
      '[id^="skip-button"]',
      '.videoAdUiSkipButton',
      'button[class*="skip"]',
    ];

    for (const sel of skipSelectors) {
      const btn = document.querySelector(sel) || player.querySelector(sel);
      if (btn && btn.offsetParent !== null) {
        btn.click();
        return true;
      }
    }

    // Fast-forward unskippable ads
    if (video.duration && isFinite(video.duration)) {
      video.muted = true;
      video.currentTime = video.duration;
      try { video.playbackRate = 16; } catch(e) {}
    }

    return true;
  }

  // Clean YouTube page ads
  function cleanYouTubeAds() {
    // Hide known ad elements
    const selector = YT_AD_SELECTORS.join(', ');
    document.querySelectorAll(selector).forEach(hideElement);

    // Remove promoted items from feed
    document.querySelectorAll('ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer').forEach(item => {
      if (item.querySelector('ytd-ad-slot-renderer, .ytd-promoted-sparkles-web-renderer, [aria-label="Ad"]')) {
        hideElement(item);
      }
    });

    // Remove items with ad badge
    document.querySelectorAll('.badge-style-type-ad, [badge-style="BADGE_STYLE_TYPE_AD"]').forEach(badge => {
      const renderer = badge.closest('ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-reel-video-renderer');
      if (renderer) hideElement(renderer);
    });

    // Remove premium upsell popups
    document.querySelectorAll('ytd-popup-container tp-yt-paper-dialog').forEach(dialog => {
      if (dialog.querySelector('yt-mealbar-promo-renderer, ytd-mealbar-promo-renderer')) {
        hideElement(dialog);
      }
    });

    // Hide overlay ad on video
    document.querySelectorAll('.ytp-ad-overlay-container, .ytp-ad-overlay-slot').forEach(el => {
      el.remove(); // Force remove, not just hide
    });
  }

  // YouTube SPA navigation observer
  function observeYouTubeNavigation() {
    let lastUrl = location.href;
    const navObserver = new MutationObserver(() => {
      if (location.href !== lastUrl) {
        lastUrl = location.href;
        setTimeout(cleanYouTubeAds, 500);
        setTimeout(cleanYouTubeAds, 1500);
        setTimeout(cleanYouTubeAds, 3000);
      }
    });
    navObserver.observe(document.body, { childList: true, subtree: true });
  }

  // Main YouTube ad blocker loop
  function startYouTubeAdBlocker() {
    cleanYouTubeAds();
    skipVideoAd();
    replaceYouTubeLogo();

    // High-frequency check for video ads (skip ASAP)
    setInterval(() => {
      skipVideoAd();
      // Also force-remove overlay ads every tick
      document.querySelectorAll('.ytp-ad-overlay-container, .ytp-ad-overlay-slot, .ytp-ad-text-overlay').forEach(el => {
        el.remove();
      });
    }, 300);


    // Regular cleanup of page ads + logo replacement
    setInterval(() => {
      cleanYouTubeAds();
      replaceYouTubeLogo();
    }, 2000);

    // Watch for navigation
    if (document.body) {
      observeYouTubeNavigation();
    } else {
      document.addEventListener('DOMContentLoaded', observeYouTubeNavigation);
    }

    // MutationObserver for YouTube ad elements + class changes
    const ytObserver = new MutationObserver((mutations) => {
      let shouldClean = false;
      for (const mutation of mutations) {
        // Watch for ad-showing class on player
        if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
          const el = mutation.target;
          if (el.classList && (el.classList.contains('ad-showing') || el.classList.contains('ad-interrupting'))) {
            skipVideoAd();
          }
        }
        // Watch for new ad elements
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) {
            const tagName = node.tagName ? node.tagName.toUpperCase() : '';
            if (tagName.startsWith('YTD-AD') ||
                tagName === 'YTD-PROMOTED-SPARKLES-WEB-RENDERER' ||
                tagName === 'YTD-DISPLAY-AD-RENDERER' ||
                tagName === 'YTD-IN-FEED-AD-LAYOUT-RENDERER' ||
                tagName === 'YTD-BANNER-PROMO-RENDERER' ||
                tagName === 'YTD-MEALBAR-PROMO-RENDERER') {
              shouldClean = true;
            }
            if (node.classList && (node.classList.contains('ytp-ad-module') || node.classList.contains('ytp-ad-overlay-container'))) {
              shouldClean = true;
            }
          }
        }
      }
      if (shouldClean) cleanYouTubeAds();
    });

    const observeTarget = document.body || document.documentElement;
    ytObserver.observe(observeTarget, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class']
    });
  }

  // ============================================================
  // Initialize
  // ============================================================
  async function init() {
    const active = await shouldFilter();
    if (!active) return;

    // Initial scan
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', scanAndHide);
    } else {
      scanAndHide();
    }

    // Observe for dynamic ads
    observeDOM();

    // Re-scan after page fully loads
    window.addEventListener('load', () => {
      setTimeout(scanAndHide, 1000);
      setTimeout(scanAndHide, 3000);
      setTimeout(scanAndHide, 5000);
    });

    // YouTube-specific blocking
    if (isYouTube) {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', startYouTubeAdBlocker);
      } else {
        startYouTubeAdBlocker();
      }
    }

    // ============================================================
    // Movie site video player ad skipper (rophim, phimmoi, etc.)
    // ============================================================
    if (!isYouTube) {
      function skipMovieSiteAds() {
        // Check for ad indicators
        var skipad = document.getElementById('skipad');
        var adsmessage = document.getElementById('adsmessage');
        var admute = document.getElementById('admute');
        var isAdPlaying = false;

        if (skipad && skipad.style.display !== 'none') isAdPlaying = true;
        if (adsmessage && adsmessage.style.display !== 'none') isAdPlaying = true;

        // JWPlayer ad indicators
        var jwAdNotice = document.querySelector('.jw-ad-notice');
        var jwAdSkip = document.querySelector('.jw-ad-skip');
        if (jwAdNotice || jwAdSkip) isAdPlaying = true;

        if (isAdPlaying) {
          // Click skip button
          if (skipad) skipad.click();
          if (jwAdSkip) jwAdSkip.click();

          // Fast-forward ad video
          var video = document.querySelector('#player video, #box-player video, .jw-video');
          if (video) {
            video.muted = true;
            if (video.duration && isFinite(video.duration)) {
              video.currentTime = video.duration;
            }
            try { video.playbackRate = 16; } catch(e) {}
          }
        }
      }

      // Run frequently to catch ads ASAP
      setInterval(skipMovieSiteAds, 300);

      // Also observe DOM for ad elements appearing
      if (document.body || document.documentElement) {
        var adObserver = new MutationObserver(function() {
          skipMovieSiteAds();
        });
        var observeTarget = document.body || document.documentElement;
        adObserver.observe(observeTarget, { childList: true, subtree: true, attributes: true });
      }
    }
  }

  // ============================================================
  // YouTube Premium Speed Controller
  // Unlocks playback speeds beyond 2x using HTML5 video API
  // ============================================================
  
  function initSpeedController() {
    if (!isYouTube) return;

    const SPEEDS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4, 5];
    let currentSpeed = 1;
    let controllerEl = null;
    let keepSpeedTimer = null;

    // Send speed command to MAIN world via postMessage
    // anti-detect.js (MAIN world) listens and applies the speed
    function injectSpeed(speed) {
      window.postMessage({ type: 'NDS_SET_SPEED', speed: speed }, '*');
    }

    function createSpeedController() {
      if (!document.body) return;
      if (document.getElementById('nds-speed-ctrl')) return;

      var style = document.createElement('style');
      style.id = 'nds-speed-styles';
      style.textContent = '#nds-speed-ctrl{position:fixed;bottom:80px;right:20px;z-index:99999;background:rgba(15,15,25,.92);backdrop-filter:blur(12px);border:1px solid rgba(108,92,231,.4);border-radius:14px;padding:10px 14px;display:none;flex-direction:column;gap:6px;font-family:"Segoe UI",Arial,sans-serif;box-shadow:0 8px 32px rgba(0,0,0,.5),0 0 15px rgba(108,92,231,.2)}#nds-speed-ctrl.visible{display:flex!important}#nds-speed-ctrl .nds-title{color:#a78bfa;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1.5px;text-align:center;margin-bottom:2px}#nds-speed-ctrl .nds-speeds{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}#nds-speed-ctrl .nds-speed-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#e0e0e0;border-radius:8px;padding:6px 4px;font-size:12px;font-weight:600;cursor:pointer;transition:all .15s;text-align:center;line-height:1.2}#nds-speed-ctrl .nds-speed-btn:hover{background:rgba(108,92,231,.3);border-color:rgba(108,92,231,.6);color:#fff}#nds-speed-ctrl .nds-speed-btn.active{background:linear-gradient(135deg,#6C5CE7,#4f46e5);border-color:#6C5CE7;color:#fff;box-shadow:0 0 10px rgba(108,92,231,.4)}#nds-speed-ctrl .nds-speed-btn.premium{color:#fbbf24}#nds-speed-ctrl .nds-speed-btn.premium.active{color:#fff}#nds-speed-ctrl .nds-hint{color:rgba(255,255,255,.35);font-size:9px;text-align:center;margin-top:2px}#nds-speed-toggle{position:fixed;bottom:80px;right:20px;z-index:99998;width:42px;height:42px;background:linear-gradient(135deg,#6C5CE7,#4f46e5);border:none;border-radius:50%;color:#fff;font-size:13px;font-weight:800;cursor:pointer;box-shadow:0 4px 15px rgba(108,92,231,.5);display:flex;align-items:center;justify-content:center;transition:all .2s;font-family:"Segoe UI",Arial,sans-serif}#nds-speed-toggle:hover{transform:scale(1.1);box-shadow:0 6px 20px rgba(108,92,231,.7)}#nds-speed-indicator{position:fixed;top:80px;left:50%;transform:translateX(-50%) scale(.8);z-index:99999;background:rgba(15,15,25,.85);backdrop-filter:blur(8px);color:#a78bfa;padding:8px 20px;border-radius:30px;font-size:18px;font-weight:700;font-family:"Segoe UI",Arial,sans-serif;pointer-events:none;opacity:0;transition:opacity .3s,transform .3s;border:1px solid rgba(108,92,231,.3)}#nds-speed-indicator.show{opacity:1;transform:translateX(-50%) scale(1)}';
      document.head.appendChild(style);

      var ctrl = document.createElement('div');
      ctrl.id = 'nds-speed-ctrl';
      
      var title = document.createElement('div');
      title.className = 'nds-title';
      title.textContent = '\u26A1 Speed Control';
      ctrl.appendChild(title);

      var speedsDiv = document.createElement('div');
      speedsDiv.className = 'nds-speeds';
      
      SPEEDS.forEach(function(spd) {
        var btn = document.createElement('button');
        btn.className = 'nds-speed-btn' + (spd > 2 ? ' premium' : '') + (spd === 1 ? ' active' : '');
        btn.setAttribute('data-speed', spd);
        btn.textContent = spd + 'x';
        btn.addEventListener('click', function() { setVideoSpeed(spd); });
        speedsDiv.appendChild(btn);
      });
      ctrl.appendChild(speedsDiv);

      var hint = document.createElement('div');
      hint.className = 'nds-hint';
      hint.textContent = 'D: t\u0103ng \u2022 S: gi\u1EA3m \u2022 R: reset';
      ctrl.appendChild(hint);

      document.body.appendChild(ctrl);
      controllerEl = ctrl;

      var toggle = document.createElement('button');
      toggle.id = 'nds-speed-toggle';
      toggle.textContent = '1x';
      toggle.title = 'NextDNS Shield Speed Control';
      document.body.appendChild(toggle);

      var indicator = document.createElement('div');
      indicator.id = 'nds-speed-indicator';
      document.body.appendChild(indicator);

      toggle.addEventListener('click', function(e) {
        e.stopPropagation();
        ctrl.classList.toggle('visible');
      });

      document.addEventListener('click', function(e) {
        if (ctrl && !ctrl.contains(e.target) && e.target.id !== 'nds-speed-toggle') {
          ctrl.classList.remove('visible');
        }
      });
    }

    function setVideoSpeed(speed) {
      injectSpeed(speed);
      currentSpeed = speed;

      var toggle = document.getElementById('nds-speed-toggle');
      if (toggle) {
        toggle.textContent = speed + 'x';
        toggle.style.background = speed > 2 
          ? 'linear-gradient(135deg, #f59e0b, #d97706)' 
          : 'linear-gradient(135deg, #6C5CE7, #4f46e5)';
      }

      if (controllerEl) {
        var btns = controllerEl.querySelectorAll('.nds-speed-btn');
        for (var i = 0; i < btns.length; i++) {
          var btnSpd = parseFloat(btns[i].getAttribute('data-speed'));
          if (Math.abs(btnSpd - speed) < 0.01) {
            btns[i].classList.add('active');
          } else {
            btns[i].classList.remove('active');
          }
        }
      }

      showSpeedIndicator(speed);

      // Clear old timer, set new one
      if (keepSpeedTimer) { clearInterval(keepSpeedTimer); keepSpeedTimer = null; }
      
      if (speed !== 1) {
        keepSpeedTimer = setInterval(function() {
          var video = document.querySelector('video');
          if (!video) return;
          // For speeds > 2x, always re-inject because getter is overridden
          if (currentSpeed > 2) {
            injectSpeed(currentSpeed);
          } else if (Math.abs(video.playbackRate - currentSpeed) > 0.01) {
            injectSpeed(currentSpeed);
          }
        }, 2000); // Less aggressive for stability
      }
    }

    var indicatorTimeout = null;
    function showSpeedIndicator(speed) {
      var indicator = document.getElementById('nds-speed-indicator');
      if (!indicator) return;
      indicator.textContent = speed > 2 ? '\u26A1 ' + speed + 'x Premium' : speed + 'x';
      indicator.style.color = speed > 2 ? '#fbbf24' : '#a78bfa';
      indicator.classList.add('show');
      if (indicatorTimeout) clearTimeout(indicatorTimeout);
      indicatorTimeout = setTimeout(function() {
        indicator.classList.remove('show');
      }, 1200);
    }

    function isInputFocused() {
      var el = document.activeElement;
      if (!el) return false;
      var tag = el.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA') return true;
      if (el.isContentEditable) return true;
      if (el.getAttribute('contenteditable') === 'true') return true;
      if (el.id === 'contenteditable-root') return true;
      if (el.closest && el.closest('[contenteditable="true"]')) return true;
      return false;
    }

    document.addEventListener('keydown', function(e) {
      if (isInputFocused()) return;
      if (!document.querySelector('video')) return;

      var handled = false;

      if (e.key === 'd' || e.key === 'D') {
        var idx = SPEEDS.indexOf(currentSpeed);
        if (idx < 0) idx = SPEEDS.indexOf(1);
        if (idx < SPEEDS.length - 1) {
          setVideoSpeed(SPEEDS[idx + 1]);
          handled = true;
        }
      } else if (e.key === 's' || e.key === 'S') {
        var idx2 = SPEEDS.indexOf(currentSpeed);
        if (idx2 < 0) idx2 = SPEEDS.indexOf(1);
        if (idx2 > 0) {
          setVideoSpeed(SPEEDS[idx2 - 1]);
          handled = true;
        }
      } else if (e.key === 'r' || e.key === 'R') {
        setVideoSpeed(1);
        handled = true;
      }

      if (handled) {
        e.preventDefault();
        e.stopPropagation();
      }
    }, true);

    // Watch for video changes (SPA navigation)
    var lastVideoSrc = '';
    function watchVideoChanges() {
      setInterval(function() {
        var video = document.querySelector('video');
        if (!video) return;
        if (video.src !== lastVideoSrc) {
          lastVideoSrc = video.src;
          if (currentSpeed !== 1) {
            setTimeout(function() { injectSpeed(currentSpeed); }, 300);
            setTimeout(function() { injectSpeed(currentSpeed); }, 800);
          }
        }
      }, 1000);
    }

    function startSpeedController() {
      if (!document.body) {
        setTimeout(startSpeedController, 300);
        return;
      }
      createSpeedController();
      watchVideoChanges();
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', startSpeedController);
    } else {
      startSpeedController();
    }
  }

  init();
  initSpeedController();
})();

